# Review: final_ma_p7 — 52 rows


---

## Row 1: P7-I1 · s. 5(1) · **KNOWN**
- **Law:** Personal Data Protection Act (Act 709) 2010  
- **Confidence:** 0.86  
- **Source:** https://www.pdp.gov.my/ppdpv1/wp-content/uploads/2024/07/UNDANG-UNDANG-MALAYSIA_AKTA_PERLINDUNGAN_DATA_PERIBADI_2010_709_MALAY_AND-ENG_V2022.pdf  
- **Coverage:** Horizontal

> **Verbatim snippet:** The processing of personal data by a data user shall be in compliance with the following Personal Data Protection Principles

**Rationale:** This section requires data users to process personal data in compliance with enumerated data protection principles. It evidences the core horizontal framework (purpose/scope + core obligation/principles) for personal-data protection.

**Notes:** Discovery: master dataset already records s. 5 of this law. Modality: shall; exceptions: none

<details><summary>Full section text (from graph)</summary>

**s. 5(1)** — (1) The processing of personal data by a data user shall be in compliance with the following Personal Data Protection Principles, namely— (a) the General Principle; (b) the Notice and Choice Principle; (c) the Disclosure Principle; (d) the Security Principle; (e) the Retention Principle; (f) the Data Integrity Principle; and (g) the Access Principle, as set out in sections 6, 7, 8, 9, 10, 11 and 12.

**s. 5(2)** — (2) Subject to sections 45 and 46, a data user who contravenes subsection (1) commits an offence and shall, on conviction, be liable to a fine not exceeding three hundred thousand ringgit or to imprisonment for a term not exceeding two years or to both. General Principle

</details>

---

## Row 2: P7-I1 · s. 5.3.1 · **KNOWN**
- **Law:** Personal Data Protection Code Of Practice For Banking Sector And Financial Institutions 2017  
- **Confidence:** 0.98  
- **Source:** https://www.pdp.gov.my/ppdpv1/wp-content/uploads/2024/08/170816-ABM-Code-Of-Practice-CLOcv04-FINAL_CLEAN.pdf  
- **Coverage:** Sectoral (Banking and financial institutions)

> **Verbatim snippet:** A Data Subject has the right to request a Data User in writing (referenced in the Act as a “Data Subject Notice”) to cease or not to begin processing personal data in relation to the Data Subject

**Rationale:** This section establishes a right to request cessation/non-beginning of processing. Maps to P7-I1 because it evidences a personal-data-protection framework, but it is sectoral (banking/financial institutions), not a comprehensive horizontal law.

**Notes:** Discovery: master dataset already records s. 5.3.1 of this law. Modality: has the right to request; exceptions: none

<details><summary>Full section text (from graph)</summary>

**s. 5.3.1** — 5.3.1 A Data Subject has the right to request a Data User in writing (referenced in the Act as a “Data Subject Notice”) to cease or not to begin processing personal data in relation to the Data Subject, where the processing causes or is likely to cause the Data Subject or another person substantial damage/distress and the said damage/distress is unwarranted.

</details>

---

## Row 3: P7-I1 · s. 5.3.3 · **KNOWN**
- **Law:** Personal Data Protection Code Of Practice For Banking Sector And Financial Institutions 2017  
- **Confidence:** 0.97  
- **Source:** https://www.pdp.gov.my/ppdpv1/wp-content/uploads/2024/08/170816-ABM-Code-Of-Practice-CLOcv04-FINAL_CLEAN.pdf  
- **Coverage:** Sectoral (Banking and financial institutions)

> **Verbatim snippet:** the Act recognises certain limitations to this right by specifically providing that a Data Subject does not have the right to prevent the processing of personal data where:-

**Rationale:** This provision limits a Data Subject’s right to prevent processing. It maps to P7-I1 because it evidences the existence of a personal-data-protection framework in the banking sector, which is recorded as framework evidence rather than absence.

**Notes:** Discovery: master dataset already records s. 5.3.3 of this law. Modality: negated limitation (exception to a right); exceptions: none

<details><summary>Full section text (from graph)</summary>

**s. 5.3.3** — 5.3.3 However, the Act recognises certain limitations to this right by specifically providing that a Data Subject does not have the right to prevent the processing of personal data where:- (i) the Data Subject has consented to the processing; (ii) the processing is necessary:  for the performance of a contract that the Data Subject has entered into; or  to take steps at the request of the Data Subject with a view to entering into a contract; or  for compliance with legal obligations that apply to the Data User, other than a contractual obligation; or  to protect the Data Subject’s “vital interests”, which is defined by the Act to mean “matters relating to life, death or security of a data subject”; or (iii) in such other cases as may be prescribed by the Minister by order published in the Gazette.

</details>

---

## Row 4: P7-I1 · s. 5.4.7 · **KNOWN**
- **Law:** Personal Data Protection Code Of Practice For Banking Sector And Financial Institutions 2017  
- **Confidence:** 0.96  
- **Source:** https://www.pdp.gov.my/ppdpv1/wp-content/uploads/2024/08/170816-ABM-Code-Of-Practice-CLOcv04-FINAL_CLEAN.pdf  
- **Coverage:** Sectoral (Banking and financial institutions)

> **Verbatim snippet:** Data Users are required to implement the above measures within a reasonable period of time.

**Rationale:** This section requires Data Users to implement measures. Maps to P7-I1 because it evidences a sectoral personal-data-protection framework in banking, which is not a comprehensive horizontal law.

**Notes:** Discovery: master dataset already records s. 5.4.7 of this law. Modality: are required to; exceptions: none

<details><summary>Full section text (from graph)</summary>

**s. 5.4.7** — 5.4.7 Data Users are required to implement the above measures within a reasonable period of time. Any processing of personal data conducted from the receipt of the notice withdrawing consent to process a Data Subject’s personal data until the above measures have been fully implemented shall not result in a breach of the Data Subject’s rights. 5.5 RIGHT TO PREVENT PROCESSING FOR PURPOSES OF DIRECT MARKETING

</details>

---

## Row 5: P7-I1 · s. 12 · **KNOWN**
- **Law:** Personal Data Protection Act (Act 709) 2010  
- **Confidence:** 0.86  
- **Source:** https://www.pdp.gov.my/ppdpv1/wp-content/uploads/2024/07/UNDANG-UNDANG-MALAYSIA_AKTA_PERLINDUNGAN_DATA_PERIBADI_2010_709_MALAY_AND-ENG_V2022.pdf  
- **Coverage:** Horizontal

> **Verbatim snippet:** A data subject shall be given access to his personal data held by a data user and be able to correct that personal data where the personal data is inaccurate, incomplete, misleading or not up-to-date, except where compliance with a request to such access or correction is refused under this Act.

**Rationale:** This section requires data users to provide data subjects access to their personal data and enable correction of inaccurate/incomplete/misleading/outdated data, subject to refusal under the Act. It evidences a horizontal core DP framework (access & rectification rights).

**Notes:** Discovery: master dataset already records s. 12 of this law. Modality: shall (with exception); exceptions: compliance with a request for access or correction is refused under this Act

<details><summary>Full section text (from graph)</summary>

**s. 12** — A data subject shall be given access to his personal data held by a data user and be able to correct that personal data where the personal data is inaccurate, incomplete, misleading or not up-to-date, except where compliance with a request to such access or correction is refused under this Act. Division 2 Registration Application of this Division

</details>

---

## Row 6: P7-I1 · s. 5.1.1 · **KNOWN**
- **Law:** Personal Data Protection Code Of Practice For Banking Sector And Financial Institutions 2017  
- **Confidence:** 0.98  
- **Source:** https://www.pdp.gov.my/ppdpv1/wp-content/uploads/2024/08/170816-ABM-Code-Of-Practice-CLOcv04-FINAL_CLEAN.pdf  
- **Coverage:** Sectoral (Banking and financial institutions)

> **Verbatim snippet:** Under the Access Principle, a Data Subject has the right to lodge a data access request (“DAR”) with the Data User and to receive a reply from the Data User within the time period set in the Act.

**Rationale:** This section establishes a sectoral access-right framework. Maps to P7-I1 because it evidences a personal-data protection framework in banking, but it is not comprehensive/horizontal across the economy.

**Notes:** Discovery: master dataset already records s. 5.1.1 of this law. Modality: has the right to; exceptions: none

<details><summary>Full section text (from graph)</summary>

**s. 5.1.1** — 5.1.1 Under the Access Principle, a Data Subject has the right to lodge a data access request (“DAR”) with the Data User and to receive a reply from the Data User within the time period set in the Act.

</details>

---

## Row 7: P7-I1 · s. 5.1.2 · **KNOWN**
- **Law:** Personal Data Protection Code Of Practice For Banking Sector And Financial Institutions 2017  
- **Confidence:** 0.97  
- **Source:** https://www.pdp.gov.my/ppdpv1/wp-content/uploads/2024/08/170816-ABM-Code-Of-Practice-CLOcv04-FINAL_CLEAN.pdf  
- **Coverage:** Sectoral (Banking and financial institutions)

> **Verbatim snippet:** 5.1.2 A DAR may also be made on behalf of the Data Subject by the following persons:

**Rationale:** This section permits who may make a data access/correction request on behalf of a data subject. Maps to P7-I1 because it evidences a personal-data-protection framework in the banking sector, which is sectoral rather than comprehensive horizontal law.

**Notes:** Discovery: master dataset already records s. 5.1.2 of this law. Modality: may; exceptions: none

<details><summary>Full section text (from graph)</summary>

**s. 5.1.2** — 5.1.2 A DAR may also be made on behalf of the Data Subject by the following persons: (i) in the case of a Data Subject who is below the age of eighteen years, the parent, guardian or person who has parental responsibility for the Data Subject; or (ii) in the case of a Data Subject who is incapable of managing his own affairs, a person who is appointed by a court to manage those affairs, or a person authorized in writing by the Data Subject to act on behalf of the Data Subject; or (iii) in any other case, a person authorized in writing by the Data Subject to make a data access request, data correction request, or both such requests, on behalf of the Data Subject, (collectively referred to as the “Relevant Persons” and for the purpose of this Part 5, the Data Subject or the Relevant Person making the DAR or DCR (defined in 5.2.1 below) shall be referred to as the "Requestor"). Ambit Of A DAR

</details>

---

## Row 8: P7-I1 · s. 5.1.6 · **KNOWN**
- **Law:** Personal Data Protection Code Of Practice For Banking Sector And Financial Institutions 2017  
- **Confidence:** 0.95  
- **Source:** https://www.pdp.gov.my/ppdpv1/wp-content/uploads/2024/08/170816-ABM-Code-Of-Practice-CLOcv04-FINAL_CLEAN.pdf  
- **Coverage:** Sectoral (Banking and financial institutions)

> **Verbatim snippet:** The Regulations provide that where a Requestor does not require a copy of the personal data, the Requestor must inform the Data User in writing of the Requestor’s intention of making a DAR.

**Rationale:** This provision requires a Requestor to notify the Data User in writing in a DAR context. It maps to P7-I1 because it evidences a sectoral personal-data framework, not a comprehensive horizontal law.

**Notes:** Discovery: master dataset already records s. 5.1.6 of this law. Modality: must; exceptions: none

<details><summary>Full section text (from graph)</summary>

**s. 5.1.6** — 5.1.6 The Regulations provide that where a Requestor does not require a copy of the personal data, the Requestor must inform the Data User in writing of the Requestor’s intention of making a DAR. This would presuppose that Data Users are required to provide the Requestor with a choice at the point of making a DAR, of either: (i) confirming whether or not the Data User retains any personal data in respect of the said Data Subject; or (ii) providing the Requestor with a copy of the personal data that the Requestor is seeking as per 5.1.3.

</details>

---

## Row 9: P7-I1 · s. 5.1.7 · **KNOWN**
- **Law:** Personal Data Protection Code Of Practice For Banking Sector And Financial Institutions 2017  
- **Confidence:** 0.97  
- **Source:** https://www.pdp.gov.my/ppdpv1/wp-content/uploads/2024/08/170816-ABM-Code-Of-Practice-CLOcv04-FINAL_CLEAN.pdf  
- **Coverage:** Sectoral (Banking sector and financial institutions)

> **Verbatim snippet:** A DAR needs to be specific as to the personal data that is being sought.

**Rationale:** This section requires specificity in data access requests. Maps to P7-I1 because it evidences a sectoral personal-data framework in banking, which is not a comprehensive horizontal law.

**Notes:** Discovery: master dataset already records s. 5.1.7 of this law. Modality: needs to; exceptions: A request for “all personal data” shall not be considered to be a proper DAR

<details><summary>Full section text (from graph)</summary>

**s. 5.1.7** — 5.1.7 A DAR needs to be specific as to the personal data that is being sought. In this context, a request for “all personal data” shall not be considered to be a proper DAR.

</details>

---

## Row 10: P7-I1 · s. 5.1.8 · **KNOWN**
- **Law:** Personal Data Protection Code Of Practice For Banking Sector And Financial Institutions 2017  
- **Confidence:** 0.98  
- **Source:** https://www.pdp.gov.my/ppdpv1/wp-content/uploads/2024/08/170816-ABM-Code-Of-Practice-CLOcv04-FINAL_CLEAN.pdf  
- **Coverage:** Sectoral (Banking and financial institutions)

> **Verbatim snippet:** Where a Data Subject has separate accounts with a Data User, separate DARs may be required by the Data User for each account.

**Rationale:** This provision permits/requires separate DARs for separate accounts. Maps to P7-I1 because it evidences a sectoral data-protection framework in banking, not a comprehensive horizontal law.

**Notes:** Discovery: master dataset already records s. 5.1.8 of this law. Modality: may be required; exceptions: none

<details><summary>Full section text (from graph)</summary>

**s. 5.1.8** — 5.1.8 Where a Data Subject has separate accounts with a Data User, separate DARs may be required by the Data User for each account. Format Of A DAR

</details>

---

## Row 11: P7-I1 · s. 5.1.13 · **KNOWN**
- **Law:** Personal Data Protection Code Of Practice For Banking Sector And Financial Institutions 2017  
- **Confidence:** 0.98  
- **Source:** https://www.pdp.gov.my/ppdpv1/wp-content/uploads/2024/08/170816-ABM-Code-Of-Practice-CLOcv04-FINAL_CLEAN.pdf  
- **Coverage:** Sectoral (Banking and financial institutions)

> **Verbatim snippet:** 5.1.13 In line with the Regulations, a Data User is to provide written acknowledgement of having received the DAR, upon the submission of the relevant processing fee(s), if any

**Rationale:** This section requires Data Users to provide written acknowledgement of receipt of a DAR. It maps to P7-I1 only as evidence of a personal-data-protection framework existing in the banking sector; it is sectoral, not a comprehensive horizontal law.

**Notes:** Discovery: master dataset already records s. 5.1.13 of this law. Modality: is to provide; exceptions: none

<details><summary>Full section text (from graph)</summary>

**s. 5.1.13** — 5.1.13 In line with the Regulations, a Data User is to provide written acknowledgement of having received the DAR, upon the submission of the relevant processing fee(s), if any (for DAR in respect of a Data Subject's personal data, the maximum fee prescribed is RM10 with a copy and RM2 without a copy of the personal data; for DAR in respect of a Data Subject's sensitive personal data, the maximum fee prescribed is RM30 with a copy and RM5 without a copy of the sensitive personal data), if any.

</details>

---

## Row 12: P7-I1 · s. 5.1.15 · **KNOWN**
- **Law:** Personal Data Protection Code Of Practice For Banking Sector And Financial Institutions 2017  
- **Confidence:** 0.98  
- **Source:** https://www.pdp.gov.my/ppdpv1/wp-content/uploads/2024/08/170816-ABM-Code-Of-Practice-CLOcv04-FINAL_CLEAN.pdf  
- **Coverage:** Sectoral (Banking sector and financial institutions)

> **Verbatim snippet:** Where the Data User is unclear as to the specific personal data that is being sought by the Requestor, the Data User may request

**Rationale:** This section permits a banking-sector Data User to request further information. It evidences a sectoral data-protection practice, not a comprehensive horizontal framework, so P7-I1 is satisfied as sectoral-only law.

**Notes:** Discovery: master dataset already records s. 5.1.15 of this law. Modality: may; exceptions: none

<details><summary>Full section text (from graph)</summary>

**s. 5.1.15** — 5.1.15 Where the Data User is unclear as to the specific personal data that is being sought by the Requestor, the Data User may request (depending on the Data User’s respective policies) for further information, e.g. account numbers, dates of specific transactions, or description of the interaction with the Data User.

</details>

---

## Row 13: P7-I1 · s. 5.1.19 · **KNOWN**
- **Law:** Personal Data Protection Code Of Practice For Banking Sector And Financial Institutions 2017  
- **Confidence:** 0.98  
- **Source:** https://www.pdp.gov.my/ppdpv1/wp-content/uploads/2024/08/170816-ABM-Code-Of-Practice-CLOcv04-FINAL_CLEAN.pdf  
- **Coverage:** Sectoral (Banking and financial institutions)

> **Verbatim snippet:** The Act recognises that Data Users may legitimately refuse to comply with a DAR in some circumstances as detailed in section 32 of the Act.

**Rationale:** This provision permits Data Users to refuse compliance with a DAR in specified circumstances. It maps to P7-I1 because it evidences the Act’s horizontal personal-data-protection framework, which ESCAP records as the existence row.

**Notes:** Discovery: master dataset already records s. 5.1.19 of this law. Modality: may; exceptions: none

<details><summary>Full section text (from graph)</summary>

**s. 5.1.19** — 5.1.19 The Act recognises that Data Users may legitimately refuse to comply with a DAR in some circumstances as detailed in section 32 of the Act.

</details>

---

## Row 14: P7-I1 · s. 5.1.22 · **KNOWN**
- **Law:** Personal Data Protection Code Of Practice For Banking Sector And Financial Institutions 2017  
- **Confidence:** 0.96  
- **Source:** https://www.pdp.gov.my/ppdpv1/wp-content/uploads/2024/08/170816-ABM-Code-Of-Practice-CLOcv04-FINAL_CLEAN.pdf  
- **Coverage:** Sectoral (Banking and financial institutions)

> **Verbatim snippet:** Where an exemption applies to the DAR, a Data User may choose to either refuse the provision of all or some of the personal data requested, depending on the circumstances.

**Rationale:** This section permits a Data User to refuse disclosure of requested personal data when an exemption applies. It evidences a sectoral data-protection framework, so it maps to P7-I1 as sectoral-only rather than a comprehensive horizontal law.

**Notes:** Discovery: master dataset already records s. 5.1.22 of this law. Modality: may; exceptions: none

<details><summary>Full section text (from graph)</summary>

**s. 5.1.22** — 5.1.22 Where an exemption applies to the DAR, a Data User may choose to either refuse the provision of all or some of the personal data requested, depending on the circumstances. Administrative

</details>

---

## Row 15: P7-I1 · s. 5.1.24 · **KNOWN**
- **Law:** Personal Data Protection Code Of Practice For Banking Sector And Financial Institutions 2017  
- **Confidence:** 0.97  
- **Source:** https://www.pdp.gov.my/ppdpv1/wp-content/uploads/2024/08/170816-ABM-Code-Of-Practice-CLOcv04-FINAL_CLEAN.pdf  
- **Coverage:** Sectoral (Banking and financial institutions)

> **Verbatim snippet:** It is recommended that Data Users should maintain a file for each DAR with the following information:- (i) a copy of the DAR;

**Rationale:** This provision recommends that Data Users maintain records for each DAR. It evidences a sectoral data-protection framework, which counts for P7-I1 because sector-specific rules are not a comprehensive horizontal law.

**Notes:** Discovery: master dataset already records s. 5.1.24 of this law. Modality: should (recommended); exceptions: none

<details><summary>Full section text (from graph)</summary>

**s. 5.1.24** — 5.1.24 It is recommended that Data Users should maintain a file for each DAR with the following information:- (i) a copy of the DAR; (ii) a record of the verification of the identity of the Requestor; (iii) copies of all correspondences relevant to the DAR; (iv) a record of any decision made in relation to the DAR; and (v) a copy of the personal data that was sent to the Requestor in question.

</details>

---

## Row 16: P7-I1 · s. 5.1.25 · **KNOWN**
- **Law:** Personal Data Protection Code Of Practice For Banking Sector And Financial Institutions 2017  
- **Confidence:** 0.96  
- **Source:** https://www.pdp.gov.my/ppdpv1/wp-content/uploads/2024/08/170816-ABM-Code-Of-Practice-CLOcv04-FINAL_CLEAN.pdf  
- **Coverage:** Sectoral (Banking and financial institutions)

> **Verbatim snippet:** 5.2 RIGHT TO CORRECT PERSONAL DATA

**Rationale:** This section establishes the right to correct personal data. Maps to P7-I1 because it evidences a sectoral personal-data-protection framework, not a comprehensive horizontal law.

**Notes:** Discovery: master dataset already records s. 5.1.25 of this law. Modality: establishes; exceptions: Joint account mandate applies; if it requires all account holders to sign, the DAR must be issued by all joint account holders or their jointly appointed Relevant Person.

<details><summary>Full section text (from graph)</summary>

**s. 5.1.25** — 5.1.25 In handling DARs for joint accounts, the joint account mandate will apply. For example if the joint account mandate requires all account holders to sign, the DAR must be issued by all the joint account holders or by their jointly appointed Relevant Person. 5.2 RIGHT TO CORRECT PERSONAL DATA

</details>

---

## Row 17: P7-I1 · s. 5.2.1 · **KNOWN**
- **Law:** Personal Data Protection Code Of Practice For Banking Sector And Financial Institutions 2017  
- **Confidence:** 0.98  
- **Source:** https://www.pdp.gov.my/ppdpv1/wp-content/uploads/2024/08/170816-ABM-Code-Of-Practice-CLOcv04-FINAL_CLEAN.pdf  
- **Coverage:** Sectoral (Banking and financial institutions)

> **Verbatim snippet:** the said Requestor has the right to lodge a data correction request (“DCR”) requesting that one or more corrections be made to the Data Subject's personal data.

**Rationale:** This section establishes a right to lodge a data correction request. Maps to P7-I1 because it evidences a sectoral personal-data correction framework, not a comprehensive horizontal data-protection law.

**Notes:** Discovery: master dataset already records s. 5.2.1 of this law. Modality: has the right to lodge; exceptions: none

<details><summary>Full section text (from graph)</summary>

**s. 5.2.1** — 5.2.1 Pursuant to the Access Principle, where personal data of a Data Subject is processed by a Data User and that: PDP Code Of Practice For The Banking And Financial Sector Part 5 54 (i) a copy of the personal data has been supplied to the Requestor in compliance with a DAR, and the Requestor considers that the personal data is inaccurate, incomplete, misleading or not up-to-date; or (ii) the Data Subject knows that his/her personal data is inaccurate, incomplete, misleading or not up-to-date, the said Requestor has the right to lodge a data correction request (“DCR”) requesting that one or more corrections be made to the Data Subject's personal data. Ambit Of A DCR

</details>

---

## Row 18: P7-I1 · s. 5.2.2 · **KNOWN**
- **Law:** Personal Data Protection Code Of Practice For Banking Sector And Financial Institutions 2017  
- **Confidence:** 0.98  
- **Source:** https://www.pdp.gov.my/ppdpv1/wp-content/uploads/2024/08/170816-ABM-Code-Of-Practice-CLOcv04-FINAL_CLEAN.pdf  
- **Coverage:** Sectoral (Banking and financial institutions)

> **Verbatim snippet:** 5.2.2 A DCR may be made in respect of personal data that is currently within the various electronic and physical systems of the Data User as provided by the Data Subject to the Data User.

**Rationale:** This section permits a Data User to make a DCR for personal data in its systems when provided by the Data Subject. Maps to P7-I1 because it evidences a sectoral personal-data framework, not a comprehensive horizontal law.

**Notes:** Discovery: master dataset already records s. 5.2.2 of this law. Modality: may; exceptions: none

<details><summary>Full section text (from graph)</summary>

**s. 5.2.2** — 5.2.2 A DCR may be made in respect of personal data that is currently within the various electronic and physical systems of the Data User as provided by the Data Subject to the Data User.

</details>

---

## Row 19: P7-I1 · s. 5.2.4 · **KNOWN**
- **Law:** Personal Data Protection Code Of Practice For Banking Sector And Financial Institutions 2017  
- **Confidence:** 0.98  
- **Source:** https://www.pdp.gov.my/ppdpv1/wp-content/uploads/2024/08/170816-ABM-Code-Of-Practice-CLOcv04-FINAL_CLEAN.pdf  
- **Coverage:** Sectoral (Banking sector and financial institutions)

> **Verbatim snippet:** 5.2.4 A DCR does not have to be in a particular format. However, there are prerequisites that a Requestor must fulfil when making a DCR:-

**Rationale:** This section requires prerequisites for a data correction request. Maps to P7-I1 because it evidences a sectoral personal-data-protection framework in banking, which is not a comprehensive horizontal law.

**Notes:** Discovery: master dataset already records s. 5.2.4 of this law. Modality: must; exceptions: If any prerequisite is not fulfilled, the Data User should return the DCR and ask for omitted information/copies to be resubmitted.

<details><summary>Full section text (from graph)</summary>

**s. 5.2.4** — 5.2.4 A DCR does not have to be in a particular format. However, there are prerequisites that a Requestor must fulfil when making a DCR:- (i) the DCR must be in writing (as defined in Part 2); (ii) the necessary information and documentation as may be required by the Data User in order to trace and correct the personal data (e.g. name, NRIC/passport number, address, account number) as notified by the Requestor; (iii) the DCR must be specific as to the personal data that is being corrected; and (iv) relevant documentation is to be submitted in order to establish the Requestor’s right to make a request. If any one of these prerequisites is not fulfilled, the Data User should return the DCR to the Requestor and ask for the omitted information/copies to be resubmitted by the Requestor.

</details>

---

## Row 20: P7-I1 · s. 5.2.5 · **KNOWN**
- **Law:** Personal Data Protection Code Of Practice For Banking Sector And Financial Institutions 2017  
- **Confidence:** 0.98  
- **Source:** https://www.pdp.gov.my/ppdpv1/wp-content/uploads/2024/08/170816-ABM-Code-Of-Practice-CLOcv04-FINAL_CLEAN.pdf  
- **Coverage:** Sectoral (Banking and financial institutions)

> **Verbatim snippet:** Data Users may require the use of a standardised form for a DCR to be made but are not permitted to make it mandatory that such standardised forms are to be used when making a DCR.

**Rationale:** This provision permits Data Users to require a standardised form for a DCR, but forbids making it mandatory. It evidences the banking-sector data-protection framework, so it maps to P7-I1 as sectoral, not comprehensive, law.

**Notes:** Discovery: master dataset already records s. 5.2.5 of this law. Modality: may; not permitted to make mandatory; exceptions: none

<details><summary>Full section text (from graph)</summary>

**s. 5.2.5** — 5.2.5 Data Users may require the use of a standardised form for a DCR to be made but are not permitted to make it mandatory that such standardised forms are to be used when making a DCR. PDP Code Of Practice For The Banking And Financial Sector Part 5 55

</details>

---

## Row 21: P7-I1 · s. 5.2.8 · **KNOWN**
- **Law:** Personal Data Protection Code Of Practice For Banking Sector And Financial Institutions 2017  
- **Confidence:** 0.98  
- **Source:** https://www.pdp.gov.my/ppdpv1/wp-content/uploads/2024/08/170816-ABM-Code-Of-Practice-CLOcv04-FINAL_CLEAN.pdf  
- **Coverage:** Sectoral (Banking and financial institutions)

> **Verbatim snippet:** Data Users are required to provide written acknowledgement of having received a DCR upon its receipt by the Data User.

**Rationale:** This section requires Data Users to provide written acknowledgement of receipt of a DCR. It evidences the banking-sector data protection framework, which is sectoral and therefore not a comprehensive horizontal law for P7-I1.

**Notes:** Discovery: master dataset already records s. 5.2.8 of this law. Modality: required; exceptions: none

<details><summary>Full section text (from graph)</summary>

**s. 5.2.8** — 5.2.8 Data Users are required to provide written acknowledgement of having received a DCR upon its receipt by the Data User.

</details>

---

## Row 22: P7-I1 · s. 5.2.12 · **KNOWN**
- **Law:** Personal Data Protection Code Of Practice For Banking Sector And Financial Institutions 2017  
- **Confidence:** 0.98  
- **Source:** https://www.pdp.gov.my/ppdpv1/wp-content/uploads/2024/08/170816-ABM-Code-Of-Practice-CLOcv04-FINAL_CLEAN.pdf  
- **Coverage:** Sectoral (Banking sector and financial institutions)

> **Verbatim snippet:** Where appropriate, Data Users may request for supporting evidence from Requestors prior to effecting the change requested in their respective DCRs.

**Rationale:** This provision permits Data Users to request supporting evidence before changing DCRs. It evidences a sectoral data-protection control framework, so it maps to P7-I1 as sectoral-only rather than a comprehensive horizontal law.

**Notes:** Discovery: master dataset already records s. 5.2.12 of this law. Modality: may; exceptions: none

<details><summary>Full section text (from graph)</summary>

**s. 5.2.12** — 5.2.12 Where appropriate, Data Users may request for supporting evidence from Requestors prior to effecting the change requested in their respective DCRs.

</details>

---

## Row 23: P7-I1 · s. 5.2.15 · **KNOWN**
- **Law:** Personal Data Protection Code Of Practice For Banking Sector And Financial Institutions 2017  
- **Confidence:** 0.98  
- **Source:** https://www.pdp.gov.my/ppdpv1/wp-content/uploads/2024/08/170816-ABM-Code-Of-Practice-CLOcv04-FINAL_CLEAN.pdf  
- **Coverage:** Sectoral (Banking and financial institutions)

> **Verbatim snippet:** Data Users are required by the Act to maintain a record of all DCRs that they have received as well as the decisions reached in respect of complying or refusing to comply with the respective DCRs

**Rationale:** This section requires Data Users to keep DCR records. Maps to P7-I1 because it evidences a sectoral data-protection framework, not a comprehensive horizontal law.

**Notes:** Discovery: master dataset already records s. 5.2.15 of this law. Modality: required; exceptions: none

<details><summary>Full section text (from graph)</summary>

**s. 5.2.15** — 5.2.15 Data Users are required by the Act to maintain a record of all DCRs that they have received as well as the decisions reached in respect of complying or refusing to comply with the respective DCRs, in order to be able to respond to further queries from the Requestor or to justify to the Commissioner the reasons for non- compliance with a Requestor’s DCR, in the event of an enquiry or investigation being commenced by the Commissioner.

</details>

---

## Row 24: P7-I1 · s. 5.3.4 · **KNOWN**
- **Law:** Personal Data Protection Code Of Practice For Banking Sector And Financial Institutions 2017  
- **Confidence:** 0.98  
- **Source:** https://www.pdp.gov.my/ppdpv1/wp-content/uploads/2024/08/170816-ABM-Code-Of-Practice-CLOcv04-FINAL_CLEAN.pdf  
- **Coverage:** Sectoral (Banking and financial institutions)

> **Verbatim snippet:** Upon receiving a Data Subject Notice, the Data User is required to, within twenty one (21) days of such receipt, provide the Data Subject concerned with a written notice

**Rationale:** This section requires a banking-sector Data User to give notice in response to a Data Subject Notice. It evidences a sectoral data-protection framework, so it maps to P7-I1 as non-horizontal rather than comprehensive.

**Notes:** Discovery: master dataset already records s. 5.3.4 of this law. Modality: required; exceptions: none

<details><summary>Full section text (from graph)</summary>

**s. 5.3.4** — 5.3.4 Upon receiving a Data Subject Notice, the Data User is required to, within twenty one (21) days of such receipt, provide the Data Subject concerned with a written notice:- (i) stating that the Data User has complied with or intends to comply with the Data Subject Notice; or (ii) if the Data User does not intend to comply with the Data Subject Notice, to provide reasons for the decision; or (iii) stating reasons why the Data User finds the Data Subject Notice unjustified or to any extent unjustified and the extent to which the Data User has complied or intends to comply (if any). PDP Code Of Practice For The Banking And Financial Sector Part 5 59

</details>

---

## Row 25: P7-I1 · s. 5.3.6 · **KNOWN**
- **Law:** Personal Data Protection Code Of Practice For Banking Sector And Financial Institutions 2017  
- **Confidence:** 0.98  
- **Source:** https://www.pdp.gov.my/ppdpv1/wp-content/uploads/2024/08/170816-ABM-Code-Of-Practice-CLOcv04-FINAL_CLEAN.pdf  
- **Coverage:** Sectoral (Banking sector and financial institutions)

> **Verbatim snippet:** Where the Data Subject is dissatisfied with the failure of the Data User to comply with a Data Subject Notice, whether in whole or in part, the Data Subject may submit an application to the Commissioner

**Rationale:** This section permits a Data Subject to apply to the Commissioner for enforcement of a Data Subject Notice. Maps to P7-I1 because it evidences a sectoral personal-data-protection framework, which is recorded as the framework's existence rather than a comprehensive horizontal law.

**Notes:** Discovery: master dataset already records s. 5.3.6 of this law. Modality: may; exceptions: none

<details><summary>Full section text (from graph)</summary>

**s. 5.3.6** — 5.3.6 Where the Data Subject is dissatisfied with the failure of the Data User to comply with a Data Subject Notice, whether in whole or in part, the Data Subject may submit an application to the Commissioner to require the Data User to comply with the Data Subject Notice.

</details>

---

## Row 26: P7-I1 · s. 5.4.4 · **KNOWN**
- **Law:** Personal Data Protection Code Of Practice For Banking Sector And Financial Institutions 2017  
- **Confidence:** 0.93  
- **Source:** https://www.pdp.gov.my/ppdpv1/wp-content/uploads/2024/08/170816-ABM-Code-Of-Practice-CLOcv04-FINAL_CLEAN.pdf  
- **Coverage:** Sectoral (Banking and financial institutions)

> **Verbatim snippet:** Where the Data Subject has provided the Data User with details of his interests as part of his loan application to the Data User, the Data Subject may withdraw his consent for the Data User to continue retaining personal data in relation to his interests

**Rationale:** This provision permits withdrawal of consent for continued retention/processing of personal data. It evidences a horizontal personal-data-protection framework in the banking sector, so it maps to P7-I1 as framework evidence rather than absence.

**Notes:** Discovery: master dataset already records s. 5.4.4 of this law. Modality: may; exceptions: retention may continue as necessary for communication and forwarding of notices to the Data Subject as per the contract

<details><summary>Full section text (from graph)</summary>

**s. 5.4.4** — 5.4.4 The following are instances in which a Data Subject may withdraw his/her consent to the processing of his/her personal data by the Data User: Example 1: Where a Data Subject provides his/her consent to the Data User to market its other products/services to the Data Subject, the Data Subject has the right to withdraw his/her consent in relation to marketing at a subsequent date as the marketing of other products/services of the Data User is not relevant to the performance of the contract between Data Subject and the Data User. Example 2: Where the Data Subject has provided the Data User with details of his interests as part of his loan application to the Data User, the Data Subject may withdraw his consent for the Data User to continue retaining personal data in relation to his interests as it is not relevant to the performance of the contract between Data Subject and the Data User. Example 3: Where the Data Subject has provided the Data User with information in relation to the identity and ages of his/her children to the Data User, the Data Subject may withdraw his consent for the Data User to continue retaining such personal data if it is not relevant to the performance of the contract between Data Subject and the Data User. Example 4: Where the Data User maintains records of several telephone numbers and e-mails that the Data Subject may be contacted on, the Data Subject may choose to withdraw his consent for the Data User to continue retaining all the said telephone numbers and/or e-mails, other than as necessary for the purposes of communication and the forwarding of notices to the Data Subject as per the contract between Data Subject and the Data User.

</details>

---

## Row 27: P7-I1 · s. 5.4.5 · **KNOWN**
- **Law:** Personal Data Protection Code Of Practice For Banking Sector And Financial Institutions 2017  
- **Confidence:** 0.97  
- **Source:** https://www.pdp.gov.my/ppdpv1/wp-content/uploads/2024/08/170816-ABM-Code-Of-Practice-CLOcv04-FINAL_CLEAN.pdf  
- **Coverage:** Sectoral (Banking and financial institutions)

> **Verbatim snippet:** the right to withdraw consent to process personal data shall not be applicable

**Rationale:** This section establishes a sectoral limitation on the right to withdraw consent. Maps to P7-I1 because it evidences a personal-data protection framework in force, even though it is not comprehensive and is banking-sector specific.

**Notes:** Discovery: master dataset already records s. 5.4.5 of this law. Modality: shall not be applicable; exceptions: none

<details><summary>Full section text (from graph)</summary>

**s. 5.4.5** — 5.4.5 For the avoidance of doubt and further to 4.1.3 and 4.1.4, the right to withdraw consent to process personal data shall not be applicable to the information of officers, employees, authorised signatories, directors, individual shareholders, individual guarantors, individual security providers, suppliers/vendors and/or the related parties of an organization/company, where such information has been provided to a Data User by the said organization/company for the purpose of one or more commercial transactions between the said organization/company and the Data User.

</details>

---

## Row 28: P7-I1 · s. 5.4.6 · **KNOWN**
- **Law:** Personal Data Protection Code Of Practice For Banking Sector And Financial Institutions 2017  
- **Confidence:** 0.98  
- **Source:** https://www.pdp.gov.my/ppdpv1/wp-content/uploads/2024/08/170816-ABM-Code-Of-Practice-CLOcv04-FINAL_CLEAN.pdf  
- **Coverage:** Sectoral (Banking and financial institutions)

> **Verbatim snippet:** Upon the receipt and confirmation of a Data Subject’s notice withdrawing consent to process his/her personal data (“relevant personal data”), the affected Data User is required to:

**Rationale:** This section requires affected Data Users to cease processing and remove personal data upon withdrawal of consent. It evidences a sectoral data-protection framework, but not a comprehensive horizontal law, so it maps to P7-I1 as sectoral-only coverage.

**Notes:** Discovery: master dataset already records s. 5.4.6 of this law. Modality: required; exceptions: none

<details><summary>Full section text (from graph)</summary>

**s. 5.4.6** — 5.4.6 Upon the receipt and confirmation of a Data Subject’s notice withdrawing consent to process his/her personal data (“relevant personal data”), the affected Data User is required to: PDP Code Of Practice For The Banking And Financial Sector Part 5 62 (i) cease processing the Data Subject’s relevant personal data; (ii) remove the Data Subject’s relevant personal data from the Data User’s electronic and physical systems, as far as reasonably possible; (iii) remove the relevant personal data from any marketing initiatives or lists of the Data User; (iv) remove the relevant personal data from the control of data processors to the extent applicable; and (v) archive the relevant personal data for the applicable statutory period.

</details>

---

## Row 29: P7-I1 · s. 5.5.3 · **KNOWN**
- **Law:** Personal Data Protection Code Of Practice For Banking Sector And Financial Institutions 2017  
- **Confidence:** 0.98  
- **Source:** https://www.pdp.gov.my/ppdpv1/wp-content/uploads/2024/08/170816-ABM-Code-Of-Practice-CLOcv04-FINAL_CLEAN.pdf  
- **Coverage:** Sectoral (Banking and financial institutions)

> **Verbatim snippet:** The permitted practices of the banking and financial sector are addressed in greater depth in Part 4 of this Code.

**Rationale:** This section establishes the banking-sector code framework. Maps to P7-I1 because it evidences a sectoral data-protection regime, not a comprehensive horizontal personal-data-protection law.

**Notes:** Discovery: master dataset already records s. 5.5.3 of this law. Modality: are addressed; exceptions: none

<details><summary>Full section text (from graph)</summary>

**s. 5.5.3** — 5.5.3 The permitted practices of the banking and financial sector are addressed in greater depth in Part 4 of this Code.

</details>

---

## Row 30: P7-I1 · s. 5(2) · **KNOWN**
- **Law:** Personal Data Protection Act (Act 709) 2010  
- **Confidence:** 0.97  
- **Source:** https://www.pdp.gov.my/ppdpv1/wp-content/uploads/2024/07/UNDANG-UNDANG-MALAYSIA_AKTA_PERLINDUNGAN_DATA_PERIBADI_2010_709_MALAY_AND-ENG_V2022.pdf  
- **Coverage:** Horizontal

> **Verbatim snippet:** Subject to sections 45 and 46, a data user who contravenes subsection (1) commits an offence

**Rationale:** This section prohibits contravention of the General Principle by a data user. Maps to P7-I1 because it evidences the horizontal personal-data-protection framework’s core obligation, which ESCAP records as the framework’s existence.

**Notes:** Discovery: master dataset already records s. 5 of this law. Modality: prohibits; exceptions: sections 45 and 46

<details><summary>Full section text (from graph)</summary>

**s. 5(1)** — (1) The processing of personal data by a data user shall be in compliance with the following Personal Data Protection Principles, namely— (a) the General Principle; (b) the Notice and Choice Principle; (c) the Disclosure Principle; (d) the Security Principle; (e) the Retention Principle; (f) the Data Integrity Principle; and (g) the Access Principle, as set out in sections 6, 7, 8, 9, 10, 11 and 12.

**s. 5(2)** — (2) Subject to sections 45 and 46, a data user who contravenes subsection (1) commits an offence and shall, on conviction, be liable to a fine not exceeding three hundred thousand ringgit or to imprisonment for a term not exceeding two years or to both. General Principle

</details>

---

## Row 31: P7-I1 · s. 5 · **KNOWN**
- **Law:** Personal Data Protection (Amendment) Act 2024 (Act A1727)  
- **Confidence:** 0.98  
- **Source:** https://www.pdp.gov.my/ppdpv1/wp-content/uploads/2024/11/Akta-A1727-bm.pdf  
- **Coverage:** Horizontal

> **Verbatim snippet:** dengan menggantikan perkataan “pengguna data hendaklah,” dengan perkataan “pengawal data dan seseorang pemproses data hendaklah,”

**Rationale:** This amendment requires data controllers and processors to comply with s. 9. Maps to P7-I1 because it evidences the horizontal personal-data-protection framework’s operative obligations, which is the framework existence evidence row.

**Notes:** Discovery: master dataset already records s. 5 of this law. Modality: hendaklah; exceptions: none

<details><summary>Full section text (from graph)</summary>

**s. 5** — Seksyen 9 Akta ibu dipinda— (a) dalam subseksyen (1), dengan menggantikan perkataan “pengguna data hendaklah,” dengan perkataan “pengawal data dan seseorang pemproses data hendaklah,”; dan (b) dalam subseksyen (2)— (i) dengan menggantikan perkataan “pengguna data, pengguna data itu hendaklah,” dengan perkataan “seorang pengawal data, pemproses data itu hendaklah,”; (ii) dengan memotong perkataan “, memastikan bahawa pemproses data itu”; dan Undang-Undang Malaysia 6 Akta A1727 (iii) dalam teks bahasa Inggeris— (A) dalam perenggan (a), dengan menggantikan perkataan “provides” dengan perkataan “provide”; dan (B) dalam perenggan (b), dengan menggantikan perkataan “takes” dengan perkataan “take”. Penggal baharu 1a Bahagian II

</details>

---

## Row 32: P7-I1 · s. 9(1) · **KNOWN**
- **Law:** Personal Data Protection Act (Act 709) 2010  
- **Confidence:** 0.78  
- **Source:** https://www.pdp.gov.my/ppdpv1/wp-content/uploads/2024/07/UNDANG-UNDANG-MALAYSIA_AKTA_PERLINDUNGAN_DATA_PERIBADI_2010_709_MALAY_AND-ENG_V2022.pdf  
- **Coverage:** Horizontal

> **Verbatim snippet:** A data user shall, when processing personal data, take practical steps to protect the personal data from any loss, misuse, modification, unauthorized or accidental access or disclosure, alteration or destruction

**Rationale:** This section requires data users to take practical steps to protect personal data during processing. It evidences a horizontal core data-protection obligation (security safeguards), supporting existence of a comprehensive personal-data-protection framework.

**Notes:** Discovery: master dataset already records s. 9 of this law. Modality: shall (mandatory); exceptions: none

<details><summary>Full section text (from graph)</summary>

**s. 9(1)** — (1) A data user shall, when processing personal data, take practical steps to protect the personal data from any loss, misuse, modification, unauthorized or accidental access or disclosure, alteration or destruction by having regard— (a) to the nature of the personal data and the harm that would result from such loss, misuse, modification, unauthorized or accidental access or disclosure, alteration or destruction; (b) to the place or location where the personal data is stored; (c) to any security measures incorporated into any equipment in which the personal data is stored; (d) to the measures taken for ensuring the reliability, integrity and competence of personnel having access to the personal data; and (e) to the measures taken for ensuring the secure transfer of the personal data.

**s. 9(2)** — (2) Where processing of personal data is carried out by a data processor on behalf of the data user, the data user shall, for the purpose of protecting the personal data from any loss, misuse, modification, unauthorized or accidental access or disclosure, alteration or destruction, ensure that the data processor— (a) provides sufficient guarantees in respect of the technical and organizational security measures governing the processing to be carried out; and (b) takes reasonable steps to ensure compliance with those measures. Retention Principle

</details>

---

## Row 33: P7-I2 · s. 27(1) · **KNOWN**
- **Law:** Cyber Security Act (Act 854) 2024  
- **Confidence:** 0.97  
- **Source:** https://lom.agc.gov.my/ilims/upload/portal/akta/outputaktap/2177706_BI/Act%20854.pdf  
- **Coverage:** Horizontal

> **Verbatim snippet:** No person shall— (a) provide any cyber security service; or (b) advertise, or in any way hold himself out as a provider of a cyber security service, unless he holds a licence to provide a cyber security service issued under this Part.

**Rationale:** This section prohibits providing or advertising cyber security services unless licensed. It establishes a dedicated cybersecurity licensing framework, which evidences the existence of a cybersecurity legal framework for P7-I2.

**Notes:** Discovery: master dataset already records s. 27 of this law. Modality: Prohibitive (shall not) with licence condition; exceptions: Unless he holds a licence to provide a cyber security service issued under this Part

<details><summary>Full section text (from graph)</summary>

**s. 27(1)** — (1) No person shall— (a) provide any cyber security service; or (b) advertise, or in any way hold himself out as a provider of a cyber security service, unless he holds a licence to provide a cyber security service issued under this Part.

**s. 27(2)** — (2) The Minister may prescribe any cyber security service in respect of which a licence shall be obtained under this Part.

**s. 27(3)** — (3) This Part shall not apply in the case where the cyber security service is provided by a company to its related company.

**s. 27(4)** — (4) In this section, “related company” has the meaning assigned to it in the Companies Act 2016 [Act 777].

**s. 27(5)** — (5) Any person who contravenes subsection (1) commits an offence and shall, on conviction, be liable to a fine not exceeding five hundred thousand ringgit or to imprisonment for a term not exceeding ten years or to both. Qualifications for application of licence

</details>

---

## Row 34: P7-I2 · s. 27(2) · **KNOWN**
- **Law:** Cyber Security Act (Act 854) 2024  
- **Confidence:** 0.97  
- **Source:** https://lom.agc.gov.my/ilims/upload/portal/akta/outputaktap/2177706_BI/Act%20854.pdf  
- **Coverage:** Horizontal

> **Verbatim snippet:** The Minister may prescribe any cyber security service in respect of which a licence shall be obtained under this Part.

**Rationale:** This provision permits the Minister to prescribe licensable cyber security services. It establishes a dedicated cybersecurity licensing framework, which is evidence of a cybersecurity law for P7-I2.

**Notes:** Discovery: master dataset already records s. 27 of this law. Modality: may; exceptions: none

<details><summary>Full section text (from graph)</summary>

**s. 27(1)** — (1) No person shall— (a) provide any cyber security service; or (b) advertise, or in any way hold himself out as a provider of a cyber security service, unless he holds a licence to provide a cyber security service issued under this Part.

**s. 27(2)** — (2) The Minister may prescribe any cyber security service in respect of which a licence shall be obtained under this Part.

**s. 27(3)** — (3) This Part shall not apply in the case where the cyber security service is provided by a company to its related company.

**s. 27(4)** — (4) In this section, “related company” has the meaning assigned to it in the Companies Act 2016 [Act 777].

**s. 27(5)** — (5) Any person who contravenes subsection (1) commits an offence and shall, on conviction, be liable to a fine not exceeding five hundred thousand ringgit or to imprisonment for a term not exceeding ten years or to both. Qualifications for application of licence

</details>

---

## Row 35: P7-I2 · s. 15(1) · **KNOWN**
- **Law:** Cyber Security Act (Act 854) 2024  
- **Confidence:** 0.93  
- **Source:** https://lom.agc.gov.my/ilims/upload/portal/akta/outputaktap/2177706_BI/Act%20854.pdf  
- **Coverage:** Sectoral (national critical information infrastructure sectors)

> **Verbatim snippet:** (1) The Minister may, upon the recommendation of the Chief Executive, appoint any Government Entity or person to be the national critical information infrastructure sector lead for each of the national critical information infrastructure sectors.

**Rationale:** This section permits the Minister to appoint sector leads for national critical information infrastructure sectors. It establishes a dedicated cybersecurity governance framework for critical infrastructure, so it satisfies P7-I2 because the law evidences a sector-specific cybersecurity framework.

**Notes:** Discovery: master dataset already records s. 15 of this law. Modality: may; exceptions: none

<details><summary>Full section text (from graph)</summary>

**s. 15(1)** — (1) The Minister may, upon the recommendation of the Chief Executive, appoint any Government Entity or person to be the national critical information infrastructure sector lead for each of the national critical information infrastructure sectors. Cyber Security 19

**s. 15(2)** — (2) The Minister may appoint more than one national critical information infrastructure sector lead for any of the national critical information infrastructure sectors.

**s. 15(3)** — (3) The names of the national critical information infrastructure sector leads appointed under this section shall be published in the official website of the National Cyber Security Agency. Functions of national critical information infrastructure sector lead

</details>

---

## Row 36: P7-I2 · s. 15(3) · **KNOWN**
- **Law:** Cyber Security Act (Act 854) 2024  
- **Confidence:** 0.91  
- **Source:** https://lom.agc.gov.my/ilims/upload/portal/akta/outputaktap/2177706_BI/Act%20854.pdf  
- **Coverage:** Sectoral (National critical information infrastructure)

> **Verbatim snippet:** The names of the national critical information infrastructure sector leads appointed under this section shall be published in the official website of the National Cyber Security Agency.

**Rationale:** This section requires publication of appointed national critical information infrastructure sector leads. It evidences a dedicated cybersecurity framework for critical information infrastructure governance, which is a controlling framework provision for P7-I2.

**Notes:** Discovery: master dataset already records s. 15 of this law. Modality: shall; exceptions: none

<details><summary>Full section text (from graph)</summary>

**s. 15(1)** — (1) The Minister may, upon the recommendation of the Chief Executive, appoint any Government Entity or person to be the national critical information infrastructure sector lead for each of the national critical information infrastructure sectors. Cyber Security 19

**s. 15(2)** — (2) The Minister may appoint more than one national critical information infrastructure sector lead for any of the national critical information infrastructure sectors.

**s. 15(3)** — (3) The names of the national critical information infrastructure sector leads appointed under this section shall be published in the official website of the National Cyber Security Agency. Functions of national critical information infrastructure sector lead

</details>

---

## Row 37: P7-I2 · s. 15(2) · **KNOWN**
- **Law:** Cyber Security Act (Act 854) 2024  
- **Confidence:** 0.97  
- **Source:** https://lom.agc.gov.my/ilims/upload/portal/akta/outputaktap/2177706_BI/Act%20854.pdf  
- **Coverage:** Sectoral (national critical information infrastructure sectors)

> **Verbatim snippet:** (2) The Minister may appoint more than one national critical information infrastructure sector lead for any of the national critical information infrastructure sectors.

**Rationale:** This section permits the Minister to appoint sector leads. It establishes the cybersecurity governance framework for national critical information infrastructure sectors, so it evidences a dedicated cybersecurity framework rather than its absence.

**Notes:** Discovery: master dataset already records s. 15 of this law. Modality: may; exceptions: none

<details><summary>Full section text (from graph)</summary>

**s. 15(1)** — (1) The Minister may, upon the recommendation of the Chief Executive, appoint any Government Entity or person to be the national critical information infrastructure sector lead for each of the national critical information infrastructure sectors. Cyber Security 19

**s. 15(2)** — (2) The Minister may appoint more than one national critical information infrastructure sector lead for any of the national critical information infrastructure sectors.

**s. 15(3)** — (3) The names of the national critical information infrastructure sector leads appointed under this section shall be published in the official website of the National Cyber Security Agency. Functions of national critical information infrastructure sector lead

</details>

---

## Row 38: P7-I2 · s. 27(5) · **KNOWN**
- **Law:** Cyber Security Act (Act 854) 2024  
- **Confidence:** 0.94  
- **Source:** https://lom.agc.gov.my/ilims/upload/portal/akta/outputaktap/2177706_BI/Act%20854.pdf  
- **Coverage:** Horizontal

> **Verbatim snippet:** Any person who contravenes subsection (1) commits an offence

**Rationale:** This section prohibits contravention of subsection (1). Maps to P7-I2 because it evidences a dedicated cybersecurity framework by enforcing cybersecurity licensing/compliance obligations in the Cyber Security Act.

**Notes:** Discovery: master dataset already records s. 27 of this law. Modality: prohibits; exceptions: none

<details><summary>Full section text (from graph)</summary>

**s. 27(1)** — (1) No person shall— (a) provide any cyber security service; or (b) advertise, or in any way hold himself out as a provider of a cyber security service, unless he holds a licence to provide a cyber security service issued under this Part.

**s. 27(2)** — (2) The Minister may prescribe any cyber security service in respect of which a licence shall be obtained under this Part.

**s. 27(3)** — (3) This Part shall not apply in the case where the cyber security service is provided by a company to its related company.

**s. 27(4)** — (4) In this section, “related company” has the meaning assigned to it in the Companies Act 2016 [Act 777].

**s. 27(5)** — (5) Any person who contravenes subsection (1) commits an offence and shall, on conviction, be liable to a fine not exceeding five hundred thousand ringgit or to imprisonment for a term not exceeding ten years or to both. Qualifications for application of licence

</details>

---

## Row 39: P7-I2 · s. 11(1) · **NEW**
- **Law:** Cyber Security Act (Act 854) 2024  
- **Confidence:** 0.86  
- **Source:** https://lom.agc.gov.my/ilims/upload/portal/akta/outputaktap/2177706_BI/Act%20854.pdf  
- **Coverage:** Horizontal

> **Verbatim snippet:** (1) The Chief Executive shall establish and maintain a national cyber security system known as the “National Cyber Coordination and Command Centre System” for the purpose of dealing with cyber security threats and cyber security incidents.

**Rationale:** This section requires the Chief Executive to establish and maintain a national cyber security system (coordination/command centre) to deal with cyber security threats and incidents. It evidences a dedicated cybersecurity framework (incident response/coordination).

**Notes:** Discovery: instrument is known but s. 11 is not among its recorded provisions (['15', '27', '36', '38', '39', '4', '40', '46']). Modality: shall (mandatory); exceptions: none

<details><summary>Full section text (from graph)</summary>

**s. 11(1)** — (1) The Chief Executive shall establish and maintain a national cyber security system known as the “National Cyber Coordination and Command Centre System” for the purpose of dealing with cyber security threats and cyber security incidents.

**s. 11(2)** — (2) The National Cyber Coordination and Command Centre System may contain any data or information on cyber security obtained or kept by the Chief Executive in the course of carrying out his duties under this Act.

**s. 11(3)** — (3) The Chief Executive may, in the interest of national cyber security and subject to such terms and conditions as he thinks fit, authorize any person to have access to the National Cyber Coordination and Command Centre System. Appointment of cyber security expert

</details>

---

## Row 40: P7-I2 · s. 35(4) · **NEW**
- **Law:** Cyber Security Act (Act 854) 2024  
- **Confidence:** 0.78  
- **Source:** https://lom.agc.gov.my/ilims/upload/portal/akta/outputaktap/2177706_BI/Act%20854.pdf  
- **Coverage:** Horizontal

> **Verbatim snippet:** Upon being notified by the authorized officer under paragraph (3)(b) that a cyber security incident has occurred, the Chief Executive may issue a directive to the national critical information infrastructure entity which owns or operates the national critical information infrastructure concerned on the measures necessary to respond to or recover from the cyber security incident

**Rationale:** This s.35(4) permits the Chief Executive to issue incident-response/recovery directives to national critical information infrastructure entities after notification of a cyber security incident. It evidences a dedicated cybersecurity incident response framework for critical infrastructure (incident r

**Notes:** Discovery: instrument is known but s. 35 is not among its recorded provisions (['15', '27', '36', '38', '39', '4', '40', '46']). Modality: may; exceptions: none

<details><summary>Full section text (from graph)</summary>

**s. 35(1)** — (1) Upon receipt of the notification on cyber security incident from a national critical information infrastructure entity under section 23 or if it comes to the knowledge of the Chief Executive that a cyber security incident in respect of a national critical information infrastructure has or might have occurred, the Chief Executive shall instruct an authorized officer to investigate into the matter.

**s. 35(2)** — (2) The investigation carried out under this Part shall be for the purposes of— (a) ascertaining whether a cyber security incident has occurred; or (b) in the case where a cyber security incident has occurred, determining the measures necessary to respond to or recover from the cyber security incident and preventing such cyber security incident from occurring in the future. Laws of Malaysia 34 Act 854

**s. 35(3)** — (3) Upon completion of the investigation by the authorized officer under this Part— (a) if the authorized officer finds that no cyber security incident has occurred, the authorized officer shall notify the Chief Executive about such findings and the Chief Executive shall notify the national critical information infrastructure entity which owns or operates the national critical information infrastructure referred to in subsection (1) accordingly and dismiss the matter; or (b) if the authorized officer finds that a cyber security incident has occurred, the authorized officer shall notify the Chief Executive about such findings and the Chief Executive shall notify the national critical information infrastructure entity which owns or operates the national critical information infrastructure referred to in subsection (1) accordingly.

**s. 35(4)** — (4) Upon being notified by the authorized officer under paragraph (3)(b) that a cyber security incident has occurred, the Chief Executive may issue a directive to the national critical information infrastructure entity which owns or operates the national critical information infrastructure concerned on the measures necessary to respond to or recover from the cyber security incident and to prevent such cyber security incident from occurring in the future.

**s. 35(5)** — (5) Any national critical information infrastructure entity which fails to comply with the directive of the Chief Executive under subsection (4) commits an offence and shall, on conviction, be liable to a fine not exceeding two hundred thousand ringgit or to imprisonment for a term not exceeding three years or to both. Part VIII ENFORCEMENT Authorization of public officer

</details>

---

## Row 41: P7-I3 · s. 3.5.5 · **KNOWN**
- **Law:** Personal Data Protection Code Of Practice For Banking Sector And Financial Institutions 2017  
- **Confidence:** 0.86  
- **Source:** https://www.pdp.gov.my/ppdpv1/wp-content/uploads/2024/08/170816-ABM-Code-Of-Practice-CLOcv04-FINAL_CLEAN.pdf  
- **Coverage:** Sectoral (Banking sector and financial institutions)

> **Verbatim snippet:** retain such personal data for more than seven (7) years from the date of non-approval, closure or termination of the said accounts/facilities

**Rationale:** This section permits Data Users to retain personal data for more than seven (7) years after non-approval/closure/termination. It satisfies P7-I3 because it specifies a minimum retention period threshold (>= 7 years) for the permitted retention.

**Notes:** Discovery: master dataset already records s. 3.5.5 of this law. Modality: may (permission); exceptions: Retention beyond seven (7) years is only allowed in the specified circumstances; otherwise the provision does not authorize it.

<details><summary>Full section text (from graph)</summary>

**s. 3.5.5** — 3.5.5 However, Data Users are allowed to retain such personal data for more than seven (7) years from the date of non-approval, closure or termination of the said accounts/facilities in the following circumstances: (i) if it is required by the law; (ii) if it is an obligation under the law for a Data User to report, disclose or verify a Data Subject’s details, in which case the retention period allowed in the said circumstances shall be until the disposal of the matter; (iii) the Data User can establish sufficient grounds to retain the said personal data; or (iv) the Data User is required by its regulators (e.g. Bank Negara Malaysia, Securities Commission) to continue maintaining the said personal data.

</details>

---

## Row 42: P7-I3 · s. 3.5.4 · **KNOWN**
- **Law:** Personal Data Protection Code Of Practice For Banking Sector And Financial Institutions 2017  
- **Confidence:** 0.9  
- **Source:** https://www.pdp.gov.my/ppdpv1/wp-content/uploads/2024/08/170816-ABM-Code-Of-Practice-CLOcv04-FINAL_CLEAN.pdf  
- **Coverage:** Sectoral (Banking sector and financial institutions)

> **Verbatim snippet:** until a period of seven (7) years has elapsed from the date of non-approval, closure or termination of the said accounts/facilities.

**Rationale:** This section permits Data Users to retain personal data for at least seven (7) years after non-approval/closure/termination. Maps to P7-I3 because it clearly specifies a minimum retention period (>= 7 years).

**Notes:** Discovery: master dataset already records s. 3.5.4 of this law. Modality: permitted (with specified minimum period); exceptions: none

<details><summary>Full section text (from graph)</summary>

**s. 3.5.4** — 3.5.4 As a general rule, Data Users are permitted to retain the personal data of Data Subjects from the date of application for the opening of accounts/facilities with Data Users, until a period of seven (7) years has elapsed from the date of non-approval, closure or termination of the said accounts/facilities.

</details>

---

## Row 43: P7-I3 · s. 24(2) · **KNOWN**
- **Law:** Services Tax Act (Act 807) 2018  
- **Confidence:** 0.93  
- **Source:** https://mysst.customs.gov.my/assets/document/SST%20Act/Service%20Tax%20Act%202018.pdf  
- **Coverage:** Horizontal

> **Verbatim snippet:** preserved for a period of seven years from the latest date to which the record relates

**Rationale:** This s.24(2) requires records kept under the section to be preserved for seven years. Maps to P7-I3 because it clearly specifies a minimum retention period (>= 7 years). Legal function: minimum data retention requirement.

**Notes:** Discovery: master dataset already records s. 24 of this law. Modality: must; exceptions: kept in Malaysia, except as otherwise approved by the Director General and subject to such conditions as he deems fit

<details><summary>Full section text (from graph)</summary>

**s. 24(1)** — (1) Every taxable person shall keep complete and true records written up to date of all transactions which affect or may affect his liability to service tax, including the following records: (a) all records of provision of taxable services by or to that taxable person including invoices, receipts, debit notes and credit notes; and (b) all other records as the Director General may determine.

**s. 24(2)** — (2) Any record kept under this section shall be— 28 Laws of Malaysia Act 807 (a) preserved for a period of seven years from the latest date to which the record relates; (b) in the national language or English language; and (c) kept in Malaysia, except as otherwise approved by the Director General and subject to such conditions as he deems fit.

**s. 24(3)** — (3) Where the record is in an electronically readable form, the record shall be kept in such manner as to enable the record to be readily accessible and convertible into writing.

**s. 24(4)** — (4) Where the record is originally in a manual form and is subsequently converted into an electronic form, the record shall be retained in its original form prior to the conversion.

**s. 24(5)** — (5) A copy of the record shall be admissible in evidence in any proceedings to the same extent as the record itself.

**s. 24(6)** — (6) Any person who contravenes subsection (1), (2), (3) or (4) commits an offence and shall, on conviction, be liable to a fine not exceeding fifty thousand ringgit or to imprisonment for a term not exceeding three years or to both. Taxable period

</details>

---

## Row 44: P7-I3 · s. 32(2) · **NEW**
- **Law:** Cyber Security Act (Act 854) 2024  
- **Confidence:** 0.98  
- **Source:** https://lom.agc.gov.my/ilims/upload/portal/akta/outputaktap/2177706_BI/Act%20854.pdf  
- **Coverage:** Horizontal

> **Verbatim snippet:** retained for a period of not less than six years from the date the cyber security service was provided

**Rationale:** This s.32(2) requires retention of specified information for at least six years. It satisfies P7-I3 because it clearly sets a minimum data retention period (>= 6 years). Legal function: minimum retention requirement.

**Notes:** Discovery: instrument is known but s. 32 is not among its recorded provisions (['15', '27', '36', '38', '39', '4', '40', '46']). Modality: must (retained for a period of not less than...); exceptions: none

<details><summary>Full section text (from graph)</summary>

**s. 32(1)** — (1) A licensee shall, on each occasion where the licensee is engaged to provide cyber security service, keep and maintain the following records: (a) the name and address of the person engaging the licensee for the cyber security service; (b) the name of the person providing the cyber security service on behalf of the licensee, if any; (c) the date and time of cyber security service that was provided by the licensee or other person on behalf of the licensee; (d) details of the type of cyber security service provided; and (e) such other particulars as may be determined by the Chief Executive.

**s. 32(2)** — (2) The information referred to in subsection (1) shall be— (a) kept and maintained in the manner as may be determined by the Chief Executive; (b) retained for a period of not less than six years from the date the cyber security service was provided; and (c) produced to the Chief Executive at any time as the Chief Executive may direct. Laws of Malaysia 32 Act 854

**s. 32(3)** — (3) Any person who contravenes subsection (1) or (2) commits an offence and shall, on conviction, be liable to a fine not exceeding one hundred thousand ringgit or to imprisonment for a term not exceeding two years or to both. Revocation or suspension of licence

</details>

---

## Row 45: P7-I4 · n/a · **KNOWN**
- **Law:** Personal Data Protection Act 2010 (Act 709)  
- **Confidence:** 0.6  
- **Source:** https://lom.agc.gov.my/act-detail.php?act=709  
- **Coverage:** Horizontal

> **Verbatim snippet:** NO_EVIDENCE_FOUND_PENDING_REVIEW

**Rationale:** No qualifying provision found for P7-I4 after a full-corpus sweep. The configured governing law is cited as the reference basis (score-0 pattern, A3).

**Notes:** Absence row (NO_EVIDENCE_FOUND_PENDING_REVIEW): human approval required before this becomes a score-0 final row (P3.5 A3).

<details><summary>Full section text (from graph)</summary>

(provision not found in graph)

</details>

---

## Row 46: P7-I5 · s. 40 · **KNOWN**
- **Law:** Cyber Security Act (Act 854) 2024  
- **Confidence:** 0.95  
- **Source:** https://lom.agc.gov.my/ilims/upload/portal/akta/outputaktap/2177706_BI/Act%20854.pdf  
- **Coverage:** Sectoral (cyber security)

> **Verbatim snippet:** the authorized officer may enter the premises and exercise in, upon and in respect of the premises all the powers referred to in section 39 in as full and ample a manner as if he were authorized to do so by a warrant issued under that section.

**Rationale:** This section permits an authorized officer to enter premises and exercise section 39 powers. Maps to P7-I5 because it authorizes government access to premises and related personal data without requiring prior independent judicial authorization when delay would harm the investigation.

**Notes:** Discovery: master dataset already records s. 40 of this law. Modality: may; exceptions: none

<details><summary>Full section text (from graph)</summary>

**s. 40** — If an authorized officer is satisfied upon information received that he has reasonable cause to believe that by reason of delay in obtaining a search warrant under section 39 the investigation would be adversely affected or evidence of the commission of an offence is likely to be tampered with, removed, damaged or destroyed, the authorized officer may enter the premises and exercise in, upon and in respect of the premises all the powers referred to in section 39 in as full and ample a manner as if he were authorized to do so by a warrant issued under that section. List of seized objects, etc.

</details>

---

## Row 47: P7-I5 · s. 6(1) · **KNOWN**
- **Law:** Security Offences (Special Measures) Act (Act 747) 2012  
- **Confidence:** 0.97  
- **Source:** https://lom.agc.gov.my/ilims/upload/portal/akta/outputaktap/20120622_747_BI_Act%20747%20BI.pdf  
- **Coverage:** Sectoral (Law enforcement / security offences)

> **Verbatim snippet:** the Public Prosecutor, if he considers that it is likely to contain any information relating to the commission of a security offence, may authorize any police officer— (a) to intercept, detain and open any postal article

**Rationale:** This section permits the Public Prosecutor to authorize police interception/opening of communications and postal articles. It maps to P7-I5 because government access to personal data is allowed without independent judicial authorization; the safeguard is prosecutorial, not a court order/warrant.

**Notes:** Discovery: master dataset already records s. 6 of this law. Modality: may authorize; exceptions: none

<details><summary>Full section text (from graph)</summary>

**s. 6(1)** — (1) Notwithstanding any other written law, the Public Prosecutor, if he considers that it is likely to contain any information relating to the commission of a security offence, may authorize any police officer— (a) to intercept, detain and open any postal article in the course of transmission by post; (b) to intercept any message transmitted or received by any communication; or (c) to intercept or listen to any conversation by any communication. 10 Laws of Malaysia Act 747

**s. 6(2)** — (2) The Public Prosecutor, if he considers that it is likely to contain any information relating to the communication of a security offence, may— (a) require a communications service provider to intercept and retain a specified communication or communications of a specified description received or transmitted, or about to be received or transmitted by that communications service provider; or (b) authorize a police officer to enter any premises and to install on such premises, any device for the interception and retention of a specified communication or communications of a specified description and to remove and retain such evidence.

**s. 6(3)** — (3) Notwithstanding subsection (1), a police officer not below the rank of Superintendent of Police may— (a) intercept, detain and open any postal article in the course of transmission by post; (b) intercept any message transmitted or received by any communication; or (c) intercept or listen to any conversation by any communication, without authorization of the Public Prosecutor in urgent and sudden cases where immediate action is required leaving no moment of deliberation.

**s. 6(4)** — (4) If a police officer has acted under subsection (3), he shall immediately inform the Public Prosecutor of his action and he shall then be deemed to have acted under the authorization of the Public Prosecutor.

**s. 6(5)** — (5) The court shall take cognizance of any authorization by the Public Prosecutor under this section.

**s. 6(6)** — (6) This section shall have effect notwithstanding anything inconsistent with Article 5 of the Federal Constitution. Security Offences (Special Measures) 11

**s. 6(7)** — (7) For the purpose of this section— “communication” means a communication received or transmitted by post or a telegraphic, telephonic or other communication received or transmitted by electricity, magnetism or other means; “communications service provider” means a person who provides services for the transmission or reception of communications. Part III SPECIAL PROCEDURES RELATING TO ELECTRONIC MONITORING DEVICE Special procedures relating to electronic monitoring device

</details>

---

## Row 48: P7-I5 · s. 6(3) · **KNOWN**
- **Law:** Security Offences (Special Measures) Act (Act 747) 2012  
- **Confidence:** 0.97  
- **Source:** https://lom.agc.gov.my/ilims/upload/portal/akta/outputaktap/20120622_747_BI_Act%20747%20BI.pdf  
- **Coverage:** Sectoral (Security offences / police interception powers)

> **Verbatim snippet:** without authorization of the Public Prosecutor in urgent and sudden cases where immediate action is required leaving no moment of deliberation.

**Rationale:** This section permits warrantless interception/opening/listening by police in urgent cases. Maps to P7-I5 because it establishes government access to personal data without independent judicial authorization (legal function: emergency interception).

**Notes:** Discovery: master dataset already records s. 6 of this law. Modality: may; exceptions: without authorization of the Public Prosecutor in urgent and sudden cases where immediate action is required leaving no moment of deliberation

<details><summary>Full section text (from graph)</summary>

**s. 6(1)** — (1) Notwithstanding any other written law, the Public Prosecutor, if he considers that it is likely to contain any information relating to the commission of a security offence, may authorize any police officer— (a) to intercept, detain and open any postal article in the course of transmission by post; (b) to intercept any message transmitted or received by any communication; or (c) to intercept or listen to any conversation by any communication. 10 Laws of Malaysia Act 747

**s. 6(2)** — (2) The Public Prosecutor, if he considers that it is likely to contain any information relating to the communication of a security offence, may— (a) require a communications service provider to intercept and retain a specified communication or communications of a specified description received or transmitted, or about to be received or transmitted by that communications service provider; or (b) authorize a police officer to enter any premises and to install on such premises, any device for the interception and retention of a specified communication or communications of a specified description and to remove and retain such evidence.

**s. 6(3)** — (3) Notwithstanding subsection (1), a police officer not below the rank of Superintendent of Police may— (a) intercept, detain and open any postal article in the course of transmission by post; (b) intercept any message transmitted or received by any communication; or (c) intercept or listen to any conversation by any communication, without authorization of the Public Prosecutor in urgent and sudden cases where immediate action is required leaving no moment of deliberation.

**s. 6(4)** — (4) If a police officer has acted under subsection (3), he shall immediately inform the Public Prosecutor of his action and he shall then be deemed to have acted under the authorization of the Public Prosecutor.

**s. 6(5)** — (5) The court shall take cognizance of any authorization by the Public Prosecutor under this section.

**s. 6(6)** — (6) This section shall have effect notwithstanding anything inconsistent with Article 5 of the Federal Constitution. Security Offences (Special Measures) 11

**s. 6(7)** — (7) For the purpose of this section— “communication” means a communication received or transmitted by post or a telegraphic, telephonic or other communication received or transmitted by electricity, magnetism or other means; “communications service provider” means a person who provides services for the transmission or reception of communications. Part III SPECIAL PROCEDURES RELATING TO ELECTRONIC MONITORING DEVICE Special procedures relating to electronic monitoring device

</details>

---

## Row 49: P7-I5 · s. 6(2) · **KNOWN**
- **Law:** Security Offences (Special Measures) Act (Act 747) 2012  
- **Confidence:** 0.97  
- **Source:** https://lom.agc.gov.my/ilims/upload/portal/akta/outputaktap/20120622_747_BI_Act%20747%20BI.pdf  
- **Coverage:** Sectoral (Communications services (telecommunications/communications providers))

> **Verbatim snippet:** may— (a) require a communications service provider to intercept and retain a specified communication or communications of a specified description

**Rationale:** This section permits the Public Prosecutor to require interception and retention of communications. Maps to P7-I5 because it authorizes government access to personal data without any independent judicial authorization; no court order/warrant is required.

**Notes:** Discovery: master dataset already records s. 6 of this law. Modality: may; exceptions: none

<details><summary>Full section text (from graph)</summary>

**s. 6(1)** — (1) Notwithstanding any other written law, the Public Prosecutor, if he considers that it is likely to contain any information relating to the commission of a security offence, may authorize any police officer— (a) to intercept, detain and open any postal article in the course of transmission by post; (b) to intercept any message transmitted or received by any communication; or (c) to intercept or listen to any conversation by any communication. 10 Laws of Malaysia Act 747

**s. 6(2)** — (2) The Public Prosecutor, if he considers that it is likely to contain any information relating to the communication of a security offence, may— (a) require a communications service provider to intercept and retain a specified communication or communications of a specified description received or transmitted, or about to be received or transmitted by that communications service provider; or (b) authorize a police officer to enter any premises and to install on such premises, any device for the interception and retention of a specified communication or communications of a specified description and to remove and retain such evidence.

**s. 6(3)** — (3) Notwithstanding subsection (1), a police officer not below the rank of Superintendent of Police may— (a) intercept, detain and open any postal article in the course of transmission by post; (b) intercept any message transmitted or received by any communication; or (c) intercept or listen to any conversation by any communication, without authorization of the Public Prosecutor in urgent and sudden cases where immediate action is required leaving no moment of deliberation.

**s. 6(4)** — (4) If a police officer has acted under subsection (3), he shall immediately inform the Public Prosecutor of his action and he shall then be deemed to have acted under the authorization of the Public Prosecutor.

**s. 6(5)** — (5) The court shall take cognizance of any authorization by the Public Prosecutor under this section.

**s. 6(6)** — (6) This section shall have effect notwithstanding anything inconsistent with Article 5 of the Federal Constitution. Security Offences (Special Measures) 11

**s. 6(7)** — (7) For the purpose of this section— “communication” means a communication received or transmitted by post or a telegraphic, telephonic or other communication received or transmitted by electricity, magnetism or other means; “communications service provider” means a person who provides services for the transmission or reception of communications. Part III SPECIAL PROCEDURES RELATING TO ELECTRONIC MONITORING DEVICE Special procedures relating to electronic monitoring device

</details>

---

## Row 50: P7-I5 · s. 6(4) · **KNOWN**
- **Law:** Security Offences (Special Measures) Act (Act 747) 2012  
- **Confidence:** 0.95  
- **Source:** https://lom.agc.gov.my/ilims/upload/portal/akta/outputaktap/20120622_747_BI_Act%20747%20BI.pdf  
- **Coverage:** Sectoral (Law enforcement / policing (security offences special measures))

> **Verbatim snippet:** he shall then be deemed to have acted under the authorization of the Public Prosecutor

**Rationale:** This section establishes deemed authorization for police action already taken under subsection (3). Maps to P7-I5 because it shows government access can proceed under Public Prosecutor authorization rather than an independent judicial warrant.

**Notes:** Discovery: master dataset already records s. 6 of this law. Modality: shall; exceptions: none

<details><summary>Full section text (from graph)</summary>

**s. 6(1)** — (1) Notwithstanding any other written law, the Public Prosecutor, if he considers that it is likely to contain any information relating to the commission of a security offence, may authorize any police officer— (a) to intercept, detain and open any postal article in the course of transmission by post; (b) to intercept any message transmitted or received by any communication; or (c) to intercept or listen to any conversation by any communication. 10 Laws of Malaysia Act 747

**s. 6(2)** — (2) The Public Prosecutor, if he considers that it is likely to contain any information relating to the communication of a security offence, may— (a) require a communications service provider to intercept and retain a specified communication or communications of a specified description received or transmitted, or about to be received or transmitted by that communications service provider; or (b) authorize a police officer to enter any premises and to install on such premises, any device for the interception and retention of a specified communication or communications of a specified description and to remove and retain such evidence.

**s. 6(3)** — (3) Notwithstanding subsection (1), a police officer not below the rank of Superintendent of Police may— (a) intercept, detain and open any postal article in the course of transmission by post; (b) intercept any message transmitted or received by any communication; or (c) intercept or listen to any conversation by any communication, without authorization of the Public Prosecutor in urgent and sudden cases where immediate action is required leaving no moment of deliberation.

**s. 6(4)** — (4) If a police officer has acted under subsection (3), he shall immediately inform the Public Prosecutor of his action and he shall then be deemed to have acted under the authorization of the Public Prosecutor.

**s. 6(5)** — (5) The court shall take cognizance of any authorization by the Public Prosecutor under this section.

**s. 6(6)** — (6) This section shall have effect notwithstanding anything inconsistent with Article 5 of the Federal Constitution. Security Offences (Special Measures) 11

**s. 6(7)** — (7) For the purpose of this section— “communication” means a communication received or transmitted by post or a telegraphic, telephonic or other communication received or transmitted by electricity, magnetism or other means; “communications service provider” means a person who provides services for the transmission or reception of communications. Part III SPECIAL PROCEDURES RELATING TO ELECTRONIC MONITORING DEVICE Special procedures relating to electronic monitoring device

</details>

---

## Row 51: P7-I5 · s. 114 · **KNOWN**
- **Law:** Personal Data Protection Act (Act 709) 2010  
- **Confidence:** 0.97  
- **Source:** https://www.pdp.gov.my/ppdpv1/wp-content/uploads/2024/07/UNDANG-UNDANG-MALAYSIA_AKTA_PERLINDUNGAN_DATA_PERIBADI_2010_709_MALAY_AND-ENG_V2022.pdf  
- **Coverage:** Sectoral (personal data protection / investigations under Act 709)

> **Verbatim snippet:** the authorized officer may enter the premises and exercise in, upon and in respect of the premises all the powers referred to in section 113 in as full and ample a manner as if he were authorized to do so by a warrant issued under that section.

**Rationale:** This section permits an authorized officer to enter premises and exercise section 113 powers. Maps to P7-I5 because it authorizes access without prior independent judicial authorization when delay would harm the investigation or evidence may be tampered with.

**Notes:** Discovery: master dataset already records s. 114 of this law. Modality: may; exceptions: none

<details><summary>Full section text (from graph)</summary>

**s. 114** — If an authorized officer is satisfied upon information received that he has reasonable cause to believe that by reason of delay in obtaining a search warrant under section 113 the investigation would be adversely affected or evidence of the commission of an offence is likely to be tampered with, removed, damaged or destroyed, the authorized officer may enter the premises and exercise in, upon and in respect of the premises all the powers referred to in section 113 in as full and ample a manner as if he were authorized to do so by a warrant issued under that section. Access to computerized data

</details>

---

## Row 52: P7-I5 · s. 115(1) · **NEW**
- **Law:** Personal Data Protection Act (Act 709) 2010  
- **Confidence:** 0.91  
- **Source:** https://www.pdp.gov.my/ppdpv1/wp-content/uploads/2024/07/UNDANG-UNDANG-MALAYSIA_AKTA_PERLINDUNGAN_DATA_PERIBADI_2010_709_MALAY_AND-ENG_V2022.pdf  
- **Coverage:** Sectoral (Personal data protection / law enforcement searches)

> **Verbatim snippet:** An authorized officer conducting a search under sections 113 and 114 shall be given access to computerized data whether stored in a computer or otherwise.

**Rationale:** This section requires access to computerized data for an authorized officer during a search under ss. 113-114. It maps to P7-I5 because it establishes government access without stating that an independent judicial body must authorize that access.

**Notes:** Discovery: instrument is known but s. 115 is not among its recorded provisions (['1.1', '112', '113', '114', '12', '121', '129', '3.1', '3.1.5', '3.4', '4.11', '45', '5', '6', '9', 'sch1']). Modality: shall be given; exceptions: none

<details><summary>Full section text (from graph)</summary>

**s. 115(1)** — (1) An authorized officer conducting a search under sections 113 and 114 shall be given access to computerized data whether stored in a computer or otherwise.

**s. 115(2)** — (2) For the purposes of this section, “access”— (a) includes being provided with the necessary password, encryption code, decryption code, software or hardware and any other means required to enable comprehension of computerized data; and 77 Personal Data Protection (b) has the meaning assigned to it by subsections 2(2) and (5) of the Computer Crimes Act 1997 [Act 563]. Warrant admissible notwithstanding defects

</details>