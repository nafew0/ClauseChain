# Review: final_au_p6 — 4 rows


---

## Row 1: P6-I1 · n/a · **KNOWN**
- **Law:** Privacy Act 1988  
- **Confidence:** 0.6  
- **Source:** https://www.legislation.gov.au/C2004A03712/latest  
- **Coverage:** Horizontal

> **Verbatim snippet:** NO_EVIDENCE_FOUND_PENDING_REVIEW

**Rationale:** No qualifying provision found for P6-I1 after a full-corpus sweep. The configured governing law is cited as the reference basis (score-0 pattern, A3).

**Notes:** Absence row (NO_EVIDENCE_FOUND_PENDING_REVIEW): human approval required before this becomes a score-0 final row (P3.5 A3).

<details><summary>Full section text (from graph)</summary>

(provision not found in graph)

</details>

---

## Row 2: P6-I2 · s. 77(2A) · **KNOWN**
- **Law:** My Health Records Act 2012  
- **Confidence:** 0.98  
- **Source:** https://www.legislation.gov.au/C2012A00063/latest  
- **Coverage:** Sectoral (My Health Records / health records)

> **Verbatim snippet:** A person commits an offence if the person contravenes 
subsection (1).

**Rationale:** This section prohibits holding or taking records outside Australia. Maps to P6-I2 because it requires a copy/record to remain domestically by forbidding offshore storage, which is a local-storage rule.

**Notes:** Discovery: master dataset already records s. 77 of this law. Modality: prohibits; exceptions: none

<details><summary>Full section text (from graph)</summary>

**s. 77(1)** — (1) The System Operator, a registered repository operator, a registered portal operator or a registered contracted service provider that holds records for the purposes of the My Health Record system (whether or not the records are also held for other purposes) or has access to information relating to such records, must not: (a) hold the records, or take the records, outside Australia; or (b) process or handle the information relating to the records outside Australia; or (c) cause or permit another person: (i) to hold the records, or take the records, outside Australia; or (ii) to process or handle the information relating to the records outside Australia.

**s. 77(2)** — (2)
 
Despite subsection (1), the System Operator is authorised, for the 
purposes of the operation or administration of the My Health 
Record system:
 
 
(a)
 
to hold and take such records outside Australia, provided that 
the records do not include:
 
 
(i)
 
personal information in relation to a healthcare recipient 
or a participant in the My Health Record system; or
 
 
(ii)
 
identifying information of an individual or entity; and
 
 
(b)
 
to process and handle such information outside Australia, 
provided that the information is neither of the following:
 
 
(i)
 
personal information in relation to a healthcare recipient 
or a participant in the My Health Record system;
 
 
(ii)
 
identifying information of an individual or entity.

**s. 77(2A)** — (2A)
 
A person commits an offence if the person contravenes 
subsection (1).
 
Penalty:
 
Imprisonment for 5 years or 300 penalty units, or both.
 
Note:
 
Where a fault element for a physical element of an offence is not 
stated, see section 5.6 of the 
Criminal Code
 for the appropriate fault 
element.

**s. 77(2B)** — (2B)
 
A person is liable to a civil penalty if the person contravenes 
subsection (1).
 
Civil penalty:
 
1,500 penalty units.

**s. 77(3)** — (3)
 
This section does not limit the operation of section 99.

</details>

---

## Row 3: P6-I3 · n/a · **KNOWN**
- **Law:** Privacy Act 1988  
- **Confidence:** 0.6  
- **Source:** https://www.legislation.gov.au/C2004A03712/latest  
- **Coverage:** Horizontal

> **Verbatim snippet:** NO_EVIDENCE_FOUND_PENDING_REVIEW

**Rationale:** No qualifying provision found for P6-I3 after a full-corpus sweep. The configured governing law is cited as the reference basis (score-0 pattern, A3).

**Notes:** Absence row (NO_EVIDENCE_FOUND_PENDING_REVIEW): human approval required before this becomes a score-0 final row (P3.5 A3).

<details><summary>Full section text (from graph)</summary>

(provision not found in graph)

</details>

---

## Row 4: P6-I4 · n/a · **KNOWN**
- **Law:** Privacy Act 1988  
- **Confidence:** 0.6  
- **Source:** https://www.legislation.gov.au/C2004A03712/latest  
- **Coverage:** Horizontal

> **Verbatim snippet:** NO_EVIDENCE_FOUND_PENDING_REVIEW

**Rationale:** No qualifying provision found for P6-I4 after a full-corpus sweep. The configured governing law is cited as the reference basis (score-0 pattern, A3).

**Notes:** Absence row (NO_EVIDENCE_FOUND_PENDING_REVIEW): human approval required before this becomes a score-0 final row (P3.5 A3).

<details><summary>Full section text (from graph)</summary>

(provision not found in graph)

</details>