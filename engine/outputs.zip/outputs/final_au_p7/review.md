# Review: final_au_p7 — 11 rows


---

## Row 1: P7-I1 · n/a · **KNOWN**
- **Law:** Privacy Act 1988  
- **Confidence:** 0.6  
- **Source:** https://www.legislation.gov.au/C2004A03712/latest  
- **Coverage:** Horizontal

> **Verbatim snippet:** NO_EVIDENCE_FOUND_PENDING_REVIEW

**Rationale:** No qualifying provision found for P7-I1 after a full-corpus sweep. The configured governing law is cited as the reference basis (score-0 pattern, A3).

**Notes:** Absence row (NO_EVIDENCE_FOUND_PENDING_REVIEW): human approval required before this becomes a score-0 final row (P3.5 A3).

<details><summary>Full section text (from graph)</summary>

(provision not found in graph)

</details>

---

## Row 2: P7-I2 · s. 3 · **NEW**
- **Law:** Security of Critical Infrastructure Act 2018  
- **Confidence:** 0.86  
- **Source:** https://www.legislation.gov.au/C2018A00029/latest  
- **Coverage:** Horizontal

> **Verbatim snippet:** (d)
 
imposing enhanced cyber security obligations on relevant 
entities for systems of national significance in order to 
improve their preparedness for, and ability to respond to, 
cyber security incidents;

**Rationale:** This section establishes a critical-infrastructure risk framework that includes enhanced cybersecurity obligations and incident preparedness/response for systems of national significance. Maps to P7-I2 because it evidences a dedicated horizontal cybersecurity framework for critical infrastructure.

**Notes:** Discovery: instrument is known but s. 3 is not among its recorded provisions (none recorded). Modality: imposing; exceptions: none

<details><summary>Full section text (from graph)</summary>

**s. 3** — The object of this Act is to provide a framework for managing risks 
relating to critical infrastructure, including by:
 
 
(a)
 
improving the transparency of the ownership and operational 
control of critical infrastructure in Australia in order to better 
understand those risks; and
 
 
(b)
 
facilitating cooperation and collaboration between all levels 
of government, and regulators, owners and operators of 
critical infrastructure, in order to identify and manage those 
risks; and
 
 
(c)
 
requiring responsible entities for critical infrastructure assets 
to identify and manage risks relating to those assets; and
 
 
(d)
 
imposing enhanced cyber security obligations on relevant 
entities for systems of national significance in order to 
improve their preparedness for, and ability to respond to, 
cyber security incidents; and
 
 
(da)
 
imposing enhanced security obligations on responsible 
entities for critical telecommunications assets; and
 
 
(e)
 
providing a regime for the Commonwealth to respond to 
serious incidents relating to critical infrastructure assets.

</details>

---

## Row 3: P7-I2 · s. 30CN(1) · **NEW**
- **Law:** Security of Critical Infrastructure Act 2018  
- **Confidence:** 0.78  
- **Source:** https://www.legislation.gov.au/C2018A00029/latest  
- **Coverage:** Sectoral (Critical infrastructure (systems of national significance))

> **Verbatim snippet:** A 
cyber security exercise
 is an exercise:
 
 
(a)
 
that is undertaken by the responsible entity for a system of 
national significance; and
 
 
(b)
 
that relates to the system; and
 
 
(c)
 
that either:

**Rationale:** This s.30CN(1) establishes an obligation framework for cyber security exercises by responsible entities for systems of national significance, including incident-response testing and mitigation. Legal function: dedicated cyber incident preparedness/response framework element.

**Notes:** Discovery: instrument is known but s. 30CN is not among its recorded provisions (none recorded). Modality: must (undertaken); exceptions: none

<details><summary>Full section text (from graph)</summary>

**s. 30CN(1)** — (1)
 
A 
cyber security exercise
 is an exercise:
 
 
(a)
 
that is undertaken by the responsible entity for a system of 
national significance; and
 
 
(b)
 
that relates to the system; and
 
 
(c)
 
that either:
 
 
(i)
 
relates to all types of cyber security incidents; or
 
 
(ii)
 
relates to one or more specified types of cyber security 
incidents; and
 
 
(d)
 
if the exercise relates to all types of cyber security 
incidents—the purpose of which is to:
 
 
(i)
 
test the entity’s ability to respond appropriately to all 
types of cyber security incidents that could have a 
relevant impact on the system; and
 
 
(ii)
 
test the entity’s preparedness to respond appropriately to 
all types of cyber security incidents that could have a 
relevant impact on the system; and
 
 
(iii)
 
test the entity’s ability to mitigate the relevant impacts 
that all types of cyber security incidents could have on 
the system; and
 
 
(e)
 
if the exercise relates to one or more specified types of cyber 
security incidents—the purpose of which is to:
 
 
(i)
 
test the entity’s ability to respond appropriately to those 
types of cyber security incidents that could have a 
relevant impact on the system; and
 
 
(ii)
 
test the entity’s preparedness to respond appropriately to 
those types of cyber security incidents that could have a 
relevant impact on the system; and
 
 
(iii)
 
test the entity’s ability to mitigate the relevant impacts 
that those types of cyber security incidents could have 
on the system; and
 
 
(f)
 
that complies with such requirements (if any) as are specified 
in the rules.

**s. 30CN(2)** — (2)
 
Requirements specified under paragraph (1)(f):
 
 
(a)
 
may be of general application; or
 
 
(b)
 
may relate to one or more specified systems of national 
significance; or
 
 
(c)
 
may relate to one or more specified types of cyber security 
incidents.
 
Note:
 
For specification by class, see subsection 13(3) of the 
Legislation Act 
2003
.

**s. 30CN(3)** — (3)
 
Subsection (2) of this section does not, by implication, limit 
subsection 33(3A) of the 
Acts Interpretation Act 1901
.

</details>

---

## Row 4: P7-I3 · s. 17(2) · **NEW**
- **Law:** My Health Records Act 2012  
- **Confidence:** 0.93  
- **Source:** https://www.legislation.gov.au/C2012A00063/latest  
- **Coverage:** Sectoral (Healthcare / National health records system (National Repositories Service))

> **Verbatim snippet:** The System Operator must ensure that the record is retained for the 
period:

**Rationale:** This s.17(2) requires the System Operator to retain uploaded records for a specified minimum period. Maps to P7-I3 because it clearly sets retention duration (30 years after death / 130 years after birth / until required destruction).

**Notes:** Discovery: instrument is known but s. 17 is not among its recorded provisions (['77']). Modality: must; exceptions: retention ends earlier if the System Operator is required to destroy the record under s.17(4) (cancellation of registration); if date of death is unknown, use 130 years after date of birth instead of 30 years after death

<details><summary>Full section text (from graph)</summary>

**s. 17(1)** — (1)
 
This section applies to a record if:
 
 
(a)
 
the record is uploaded to the National Repositories Service; 
and
 
 
(b)
 
the record includes health information that is included in the 
My Health Record of a healthcare recipient.

**s. 17(2)** — (2)
 
The System Operator must ensure that the record is retained for the 
period:
 
 
(a)
 
beginning when the record is first uploaded to the National 
Repositories Service; and
 
 
(b)
 
ending:
 
 
(i)
 
30 years after the death of the healthcare recipient; or
 
 
(ii)
 
if the System Operator does not know the date of death 
of the healthcare recipient—130 years after the date of 
birth of the healthcare recipient; or
 
 
(iii)
 
if, under subsection (3), the record is required to be 
destroyed because of the cancellation of registration of 
the healthcare recipient—when the System Operator is 
required to destroy the record under subsection (4).

**s. 17(3)** — (3)
 
If the System Operator is required to cancel the registration of the 
healthcare recipient under subsection 51(1) (cancellation on 
request), the System Operator must destroy any record that 
includes health information that is included in the My Health 
Record of the healthcare recipient, other than the following 
information:
 
 
(a)
 
the name and healthcare identifier of the healthcare recipient;
 
 
(b)
 
the name and healthcare identifier of the person who 
requested the cancellation, if different from the healthcare 
recipient;
 
 
(c)
 
the day the cancellation decision takes effect under 
subsection 51(7).

**s. 17(4)** — (4)
 
The System Operator must comply with subsection (3):
 
 
(a)
 
as soon as practicable after the cancellation decision takes 
effect under subsection 51(7); or
 
 
(b)
 
if any of the following requirements apply before the records 
are destroyed under paragraph (a)—as soon as practicable 
after the conclusion of the matter to which the requirement 
relates:
 
 
(i)
 
a court order requires the System Operator not to 
destroy records of the healthcare recipient;
 
 
(ii)
 
the System Operator is required to disclose records of 
the healthcare recipient under section 69 or 69A;
 
 
(iii)
 
the System Operator is required to disclose records of 
the healthcare recipient under a law covered by 
subsection 65(3).

**s. 17(5)** — (5) To avoid doubt, if the System Operator is required under subsection (3) to destroy a record that includes health information, the System Operator must also destroy the following: (a) any copy of the record; (b) any previous version of the record; (c) any back ‑ up version of the record.

</details>

---

## Row 5: P7-I4 · s. 33D(3) · **KNOWN**
- **Law:** Privacy Act 1988  
- **Confidence:** 0.78  
- **Source:** https://www.legislation.gov.au/C2004A03712/latest  
- **Coverage:** Horizontal

> **Verbatim snippet:** A 
privacy impact assessment
 is a written assessment of an activity 
or function that:

**Rationale:** This s.33D(3) defines what a privacy impact assessment is. It maps to P7-I4 because it is an accountability mechanism tied to the Commissioner’s power to direct agencies to provide a privacy impact assessment (DPIA). Legal FUNCTION: DPIA definition/requirement framework.

**Notes:** Discovery: master dataset already records s. 33D of this law. Modality: may-direct (implied by Part IV heading/context); exceptions: none

<details><summary>Full section text (from graph)</summary>

**s. 33D(1)** — (1)
 
If:
 
 
(a)
 
an agency proposes to engage in an activity or function 
involving the handling 
of
 personal information about 
individuals; and
 
 
(b)
 
the Commissioner considers that the activity or function 
might have a significant impact on the privacy of individuals;
 
the Commissioner may, in writing, direct the agency to give the 
Commissioner, within a specified period, a privacy impact 
assessment about the activity or function.

**s. 33D(2)** — (2)
 
A direction under subsection (1) is not a legislative instrument.

**s. 33D(3)** — (3)
 
A 
privacy impact assessment
 is a written assessment of an activity 
or function that:
 
 
(a)
 
identifies the impact that the activity or function might have 
on the privacy of individuals; and
 
 
(b)
 
sets out recommendations for managing, minimising or 
eliminating that impact.

**s. 33D(4)** — (4)
 
Subsection (3) does not limit the matters that the privacy impact 
assessment may deal with.

**s. 33D(5)** — (5)
 
A privacy impact assessment is not a legislative instrument.

**s. 33D(6)** — (6)
 
If an agency does not comply with a direction under subsection (1), 
the Commissioner must advise both of the following of the failure:
 
 
(a)
 
the Minister;
 
 
(b)
 
if another Minister is responsible for the agency—that other 
Minister.

**s. 33D(7)** — (7)
 
Before the fifth anniversary of the commencement of this section, 
the Minister must cause a review to be undertaken of whether this 
section should apply in relation to organisations.

</details>

---

## Row 6: P7-I4 · s. 33D(1) · **KNOWN**
- **Law:** Privacy Act 1988  
- **Confidence:** 0.78  
- **Source:** https://www.legislation.gov.au/C2004A03712/latest  
- **Coverage:** Sectoral (Public sector (agencies subject to the Privacy Act 1988 and the Information Commissioner’s powers))

> **Verbatim snippet:** the Commissioner may, in writing, direct the agency to give the 
Commissioner, within a specified period, a privacy impact 
assessment

**Rationale:** This s.33D(1) permits the Commissioner to direct an agency to provide a privacy impact assessment when an agency proposes handling personal information and the Commissioner considers it might have a significant privacy impact. Legal FUNCTION: DPIA direction/trigger.

**Notes:** Discovery: master dataset already records s. 33D of this law. Modality: may (discretionary direction); exceptions: none

<details><summary>Full section text (from graph)</summary>

**s. 33D(1)** — (1)
 
If:
 
 
(a)
 
an agency proposes to engage in an activity or function 
involving the handling 
of
 personal information about 
individuals; and
 
 
(b)
 
the Commissioner considers that the activity or function 
might have a significant impact on the privacy of individuals;
 
the Commissioner may, in writing, direct the agency to give the 
Commissioner, within a specified period, a privacy impact 
assessment about the activity or function.

**s. 33D(2)** — (2)
 
A direction under subsection (1) is not a legislative instrument.

**s. 33D(3)** — (3)
 
A 
privacy impact assessment
 is a written assessment of an activity 
or function that:
 
 
(a)
 
identifies the impact that the activity or function might have 
on the privacy of individuals; and
 
 
(b)
 
sets out recommendations for managing, minimising or 
eliminating that impact.

**s. 33D(4)** — (4)
 
Subsection (3) does not limit the matters that the privacy impact 
assessment may deal with.

**s. 33D(5)** — (5)
 
A privacy impact assessment is not a legislative instrument.

**s. 33D(6)** — (6)
 
If an agency does not comply with a direction under subsection (1), 
the Commissioner must advise both of the following of the failure:
 
 
(a)
 
the Minister;
 
 
(b)
 
if another Minister is responsible for the agency—that other 
Minister.

**s. 33D(7)** — (7)
 
Before the fifth anniversary of the commencement of this section, 
the Minister must cause a review to be undertaken of whether this 
section should apply in relation to organisations.

</details>

---

## Row 7: P7-I5 · s. 104(1) · **KNOWN**
- **Law:** Data Availability and Transparency Act 2022  
- **Confidence:** 0.96  
- **Source:** https://www.legislation.gov.au/C2022A00011/latest  
- **Coverage:** Sectoral (Regulatory enforcement (Data Availability and Transparency Act 2022))

> **Verbatim snippet:** the Commissioner may, by written 
notice given to the person, require the person to give the 
information, or produce the document, to the Commissioner

**Rationale:** This section permits the Commissioner to require information/documents by written notice. Maps to P7-I5 because it authorizes government access to personal data without independent judicial authorization; no court order or warrant is required.

**Notes:** Discovery: master dataset already records s. 104 of this law. Modality: may; exceptions: Section 106 limits the information and documents that may be required

<details><summary>Full section text (from graph)</summary>

**s. 104(1)** — (1)
 
If the Commissioner reasonably believes that a person has 
information or a document relevant to an investigation under 
section 101, or to any other of the Commissioner’s regulatory 
functions set out in section 45, the Commissioner may, by written 
notice given to the person, require the person to give the 
information, or produce the document, to the Commissioner within 
the period specified in the notice.
Note:
There are limits on the information and documents that may be 
required (see section 106).

**s. 104(2)** — (2)
 
If:
(a)
 
a person is given a notice under subsection (1); and
(b)
 
the notice relates to an investigation under section 101;
the person must comply with the notice.
Civil penalty:
30 penalty units.

**s. 104(3)** — (3)
 
A person commits an offence if:
(a)
 
the person is given a notice under subsection (1); and
(b)
 
the notice relates to an investigation under section 101; and
(c)
 
the person fails to comply with the notice.
Penalty:
 
Imprisonment for 6 months.

**s. 104(4)** — (4)
 
If the person produces a document to the Commissioner in 
compliance with the notice, the Commissioner:
(a)
 
may take possession of, and may make copies of, or take 
extracts from, the document; and
(b)
 
may retain possession of the document for any period 
necessary for the purposes of the investigation; and
(c)
 
must, during that period, permit any person who would be 
entitled to inspect the document if it were not in the 
Commissioner’s possession to inspect the document at any 
reasonable time.

</details>

---

## Row 8: P7-I5 · s. 104(4) · **KNOWN**
- **Law:** Data Availability and Transparency Act 2022  
- **Confidence:** 0.91  
- **Source:** https://www.legislation.gov.au/C2022A00011/latest  
- **Coverage:** Sectoral (Regulatory enforcement (Data Availability and Transparency Act 2022))

> **Verbatim snippet:** the Commissioner:
(a)
 
may take possession of, and may make copies of, or take 
extracts from, the document;

**Rationale:** This section permits the Commissioner to take possession of and copy/extract a document once produced in response to a notice. Maps to P7-I5 because it establishes government access to personal data without any independent judicial authorization requirement.

**Notes:** Discovery: master dataset already records s. 104 of this law. Modality: may; exceptions: none

<details><summary>Full section text (from graph)</summary>

**s. 104(1)** — (1)
 
If the Commissioner reasonably believes that a person has 
information or a document relevant to an investigation under 
section 101, or to any other of the Commissioner’s regulatory 
functions set out in section 45, the Commissioner may, by written 
notice given to the person, require the person to give the 
information, or produce the document, to the Commissioner within 
the period specified in the notice.
Note:
There are limits on the information and documents that may be 
required (see section 106).

**s. 104(2)** — (2)
 
If:
(a)
 
a person is given a notice under subsection (1); and
(b)
 
the notice relates to an investigation under section 101;
the person must comply with the notice.
Civil penalty:
30 penalty units.

**s. 104(3)** — (3)
 
A person commits an offence if:
(a)
 
the person is given a notice under subsection (1); and
(b)
 
the notice relates to an investigation under section 101; and
(c)
 
the person fails to comply with the notice.
Penalty:
 
Imprisonment for 6 months.

**s. 104(4)** — (4)
 
If the person produces a document to the Commissioner in 
compliance with the notice, the Commissioner:
(a)
 
may take possession of, and may make copies of, or take 
extracts from, the document; and
(b)
 
may retain possession of the document for any period 
necessary for the purposes of the investigation; and
(c)
 
must, during that period, permit any person who would be 
entitled to inspect the document if it were not in the 
Commissioner’s possession to inspect the document at any 
reasonable time.

</details>

---

## Row 9: P7-I5 · s. 25A(9) · **KNOWN**
- **Law:** Australian Security Intelligence Organisation Act 1979  
- **Confidence:** 0.93  
- **Source:** https://www.legislation.gov.au/C2004A02123/latest  
- **Coverage:** Sectoral (Computer/communications systems used by other persons)

> **Verbatim snippet:** Subsection (8) does not authorise the doing of a thing that is likely 
to:

**Rationale:** This subsection limits/withholds authorization for certain computer-access acts. Maps to P7-I5 because it is part of a computer access warrant regime, i.e. access is only lawful under warrant/judicial authorization, so it does not create warrantless government access.

**Notes:** Discovery: master dataset already records s. 25A of this law. Modality: does not authorise (limitation/constraint); exceptions: Does not authorise acts likely to materially interfere with, interrupt or obstruct communications in transit or lawful use by other persons of a computer, unless necessary for subsection (8) purposes; Does not authorise acts likely to cause material loss or damage to other persons lawfully using a computer

<details><summary>Full section text (from graph)</summary>

**s. 25A(1)** — (1) If the Director ‑ General requests the Attorney ‑ General to do so, and the Attorney ‑ General is satisfied as mentioned in subsection (2), the Attorney ‑ General may issue a warrant in accordance with this section.

**s. 25A(10)** — (10)
 
If a computer or another thing is removed from a place in 
accordance with paragraph (8)(f), the computer or thing must be 
returned to that place:
(a)
 
if returning the computer or thing would be prejudicial to 
security—when returning the computer or thing would no 
longer be prejudicial to security; or
(b)
 
otherwise—within a reasonable period.

**s. 25A(2)** — (2) The Attorney ‑ General is only to issue the warrant if he or she is satisfied that there are reasonable grounds for believing that access by the Organisation to data held in a computer (the target computer ) will substantially assist the collection of intelligence in accordance with this Act in respect of a matter (the security matter ) that is important in relation to security. Note: See section 4 for the definition of computer .

**s. 25A(3)** — (3)
 
The target computer may be any one or more of the following:
(a)
 
a particular computer;
(b)
 
a computer on particular premises;
(c)
 
a computer associated with, used by or likely to be used by, a 
person (whose identity may or may not be known).

**s. 25A(3A)** — (3A) The warrant must: (a) be signed by the Attorney ‑ General; and (b) authorise the Organisation to do specified things, subject to any restrictions or conditions specified in the warrant, in relation to the target computer; and (c) if the target computer is or includes a particular computer—specify the computer; and (d) if the target computer is or includes a computer on particular premises—specify the premises; and (e) if the target computer is or includes a computer associated with, used by or likely to be used by, a person—specify the person (whether by name or otherwise).

**s. 25A(4)** — (4) The things that may be specified are any of the following that the Attorney ‑ General considers appropriate in the circumstances: (aa) entering specified premises for the purposes of doing the things mentioned in this subsection; (aaa) entering any premises for the purposes of gaining entry to or exiting the specified premises; (a) using: (i) the target computer; or (ii) a telecommunications facility operated or provided by the Commonwealth or a carrier; or (iii) any other electronic equipment; or (iv) a data storage device; for the purpose of obtaining access to data (the relevant data ) that is relevant to the security matter and is held in the target computer at any time while the warrant is in force and, if necessary to achieve that purpose, adding, copying, deleting or altering other data in the target computer; (ab) if, having regard to other methods (if any) of obtaining access to the relevant data which are likely to be as effective, it is reasonable in all the circumstances to do so: (i) using any other computer or a communication in transit to access the relevant data; and (ii) if necessary to achieve that purpose—adding, copying, deleting or altering other data in the computer or the communication in transit; (ac) removing a computer or other thing from premises for the purposes of doing any thing specified in the warrant in accordance with this subsection, and returning the computer or other thing to the premises; (b) copying any data to which access has been obtained, that appears to be relevant to the collection of intelligence by the Organisation in accordance with this Act; (ba) intercepting a communication passing over a telecommunications system, if the interception is for the purposes of doing any thing specified in the warrant in accordance with this subsection; (c) any thing reasonably necessary to conceal the fact that any thing has been done under the warrant; (d) any other thing reasonably incidental to any of the above. Note: As a result of the warrant, a person who, by means of a telecommunications facility, obtains access to data stored in a computer etc. will not commit an offence under Part 10 ‑ 7 of the Criminal Code or equivalent State or Territory laws (provided that the person acts within the authority of the warrant).

**s. 25A(4A)** — (4A)
 
If:
(a)
 
the warrant authorises the removal of a computer or other 
thing from premises as mentioned in paragraph (4)(ac); and
(b)
 
a computer or thing is removed from the premises in 
accordance with the warrant;
the computer or thing must be returned to the premises:
(c)
 
if returning the computer or thing would be prejudicial to 
security—when returning the computer or thing would no 
longer be prejudicial to security; or
(d)
 
otherwise—within a reasonable period.

**s. 25A(5)** — (5)
 
Subsection (4) does not authorise the addition, deletion or 
alteration of data, or the doing of any thing, that is likely to:
(a)
 
materially interfere with, interrupt or obstruct a 
communication in transit or the lawful use by other persons 
of a computer unless the addition, deletion or alteration, or 
the doing of the thing, is necessary to do one or more of the 
things specified in the warrant; or
(b)
 
cause any other material loss or damage to other persons 
lawfully using a computer.

**s. 25A(5A)** — (5A)
 
The warrant must:
(a)
 
authorise the use of any force against persons and things that 
is necessary and reasonable to do the things specified in the 
warrant; and
(b)
 
if the warrant authorises entering premises—state whether 
entry is authorised to be made at any time of the day or night 
or during stated hours of the day or night.

**s. 25A(6)** — (6) The warrant must specify the period during which it is to remain in force. The period must not be more than 6 months, although the Attorney ‑ General may revoke the warrant before the period has expired.

**s. 25A(7)** — (7)
 
Subsection (6) does not prevent the issue of any further warrant.

**s. 25A(8)** — (8) If any thing has been done in relation to a computer under: (a) the warrant; or (b) this subsection; the Organisation is authorised to do any of the following: (c) any thing reasonably necessary to conceal the fact that any thing has been done under the warrant or under this subsection; (d) enter any premises where the computer is reasonably believed to be, for the purposes of doing the things mentioned in paragraph (c); (e) enter any other premises for the purposes of gaining entry to or exiting the premises referred to in paragraph (d); (f) remove the computer or another thing from any place where it is situated for the purposes of doing the things mentioned in paragraph (c), and returning the computer or other thing to that place; (g) if, having regard to other methods (if any) of doing the things mentioned in paragraph (c) which are likely to be as effective, it is reasonable in all the circumstances to do so: (i) use any other computer or a communication in transit to do those things; and (ii) if necessary to achieve that purpose—add, copy, delete or alter other data in the computer or the communication in transit; (h) intercept a communication passing over a telecommunications system, if the interception is for the purposes of doing any thing mentioned in this subsection; (i) any other thing reasonably incidental to any of the above; at the following time: (j) at any time while the warrant is in force or within 28 days after it ceases to be in force; (k) if none of the things mentioned in paragraph (c) are done within the 28 ‑ day period mentioned in paragraph (j)—at the earliest time after that 28 ‑ day period at which it is reasonably practicable to do the things mentioned in paragraph (c).

**s. 25A(9)** — (9)
 
Subsection (8) does not authorise the doing of a thing that is likely 
to:
(a)
 
materially interfere with, interrupt or obstruct:
(i)
 
a communication in transit; or
(ii)
 
the lawful use by other persons of a computer;
unless the doing of the thing is necessary to do one or more 
of the things specified in subsection (8); or
(b)
 
cause any other material loss or damage to other persons 
lawfully using a computer.

</details>

---

## Row 10: P7-I5 · s. 545(2) · **NEW**
- **Law:** Telecommunications Act 1997  
- **Confidence:** 0.93  
- **Source:** https://www.legislation.gov.au/C2004A05145/latest  
- **Coverage:** Sectoral (Telecommunications / communications enforcement)

> **Verbatim snippet:** the inspector may, with such assistance as the inspector thinks fit, 
and if necessary by force:

**Rationale:** This section permits an inspector to enter, search, and seize. Maps to P7-I5 because it authorizes government access to personal data-related premises/things without independent judicial authorization, as the power is exercisable immediately without a warrant. Function: warrantless emergency search/

**Notes:** Discovery: instrument is known but s. 545 is not among its recorded provisions (['10', '110', '317ZH', '65', '8BG']). Modality: may; exceptions: otherwise the powers would require a warrant issued under Division 3; the section creates a warrantless emergency exception

<details><summary>Full section text (from graph)</summary>

**s. 545(1)** — (1)
 
If an inspector has reasonable grounds to believe:
 
 
(a)
 
that a person is carrying anything that is connected with an 
offence against Part 21; and
 
 
(b)
 
that the exercise of the powers under this section is necessary 
to prevent the concealment, loss or destruction of a thing 
connected with a particular offence;
 
the inspector may:
 
 
(c)
 
search the person, the person’s clothing and any property in 
the person’s immediate control; and
 
 
(d)
 
seize any thing found in the course of the search;
 
so long as those powers are exercised in circumstances of such 
seriousness and urgency as to require and justify the immediate 
exercise of those powers without the authority of a warrant issued 
under Division 3.

**s. 545(2)** — (2)
 
If an inspector has reasonable grounds to believe:
 
 
(a)
 
that there is on any land or on or in any premises, vessel, 
aircraft or vehicle any thing that is connected with a 
particular offence against Part 21; and
 
 
(b)
 
that the exercise of powers conferred under this section is 
necessary to prevent the concealment, loss or destruction of 
the thing;
 
the inspector may, with such assistance as the inspector thinks fit, 
and if necessary by force:
 
 
(c)
 
enter the land, premises, vessel, aircraft or vehicle; and
 
 
(d)
 
search for the thing; and
 
 
(e)
 
seize any such thing found in the course of the search;
 
so long as those powers are exercised in circumstances of such 
seriousness and urgency as to require and justify the immediate 
exercise of those powers without the authority of a warrant issued 
under Division 3.

**s. 545(3)** — (3)
 
If an inspector may enter a vessel, aircraft or vehicle under 
subsection (2), the inspector may, for that purpose and for the 
purpose of exercising a power referred to in paragraph (2)(d) or (e), 
stop and detain the vessel, aircraft or vehicle.

**s. 545(4)** — (4)
 
A reference in this section to an 
offence against Part 21 
includes a 
reference to an offence created by section 6 of the 
Crimes Act 1914
 
or Part 2.4 of the 
Criminal Code
 that relates to Part 21 of this Act.

</details>

---

## Row 11: P7-I5 · s. 545(1) · **NEW**
- **Law:** Telecommunications Act 1997  
- **Confidence:** 0.96  
- **Source:** https://www.legislation.gov.au/C2004A05145/latest  
- **Coverage:** Sectoral (Telecommunications)

> **Verbatim snippet:** the inspector may:
 
 
(c)
 
search the person, the person’s clothing and any property in 
the person’s immediate control; and
 
 
(d)
 
seize any thing found in the course of the search;
 
so long as those powers are exercised in circumstances of such 
seriousness and urgency as to require and justify the immediate 
exercise of those powers without the authority of a warrant issued 
under Divisio

**Rationale:** This section permits an inspector to search and seize without a warrant in urgent circumstances. Maps to P7-I5 because it authorizes government access to personal data/contents without independent judicial authorization; the warrant requirement is expressly waived here.

**Notes:** Discovery: instrument is known but s. 545 is not among its recorded provisions (['10', '110', '317ZH', '65', '8BG']). Modality: may; exceptions: warrant authority under Division 3 is not required where the seriousness and urgency condition is met

<details><summary>Full section text (from graph)</summary>

**s. 545(1)** — (1)
 
If an inspector has reasonable grounds to believe:
 
 
(a)
 
that a person is carrying anything that is connected with an 
offence against Part 21; and
 
 
(b)
 
that the exercise of the powers under this section is necessary 
to prevent the concealment, loss or destruction of a thing 
connected with a particular offence;
 
the inspector may:
 
 
(c)
 
search the person, the person’s clothing and any property in 
the person’s immediate control; and
 
 
(d)
 
seize any thing found in the course of the search;
 
so long as those powers are exercised in circumstances of such 
seriousness and urgency as to require and justify the immediate 
exercise of those powers without the authority of a warrant issued 
under Division 3.

**s. 545(2)** — (2)
 
If an inspector has reasonable grounds to believe:
 
 
(a)
 
that there is on any land or on or in any premises, vessel, 
aircraft or vehicle any thing that is connected with a 
particular offence against Part 21; and
 
 
(b)
 
that the exercise of powers conferred under this section is 
necessary to prevent the concealment, loss or destruction of 
the thing;
 
the inspector may, with such assistance as the inspector thinks fit, 
and if necessary by force:
 
 
(c)
 
enter the land, premises, vessel, aircraft or vehicle; and
 
 
(d)
 
search for the thing; and
 
 
(e)
 
seize any such thing found in the course of the search;
 
so long as those powers are exercised in circumstances of such 
seriousness and urgency as to require and justify the immediate 
exercise of those powers without the authority of a warrant issued 
under Division 3.

**s. 545(3)** — (3)
 
If an inspector may enter a vessel, aircraft or vehicle under 
subsection (2), the inspector may, for that purpose and for the 
purpose of exercising a power referred to in paragraph (2)(d) or (e), 
stop and detain the vessel, aircraft or vehicle.

**s. 545(4)** — (4)
 
A reference in this section to an 
offence against Part 21 
includes a 
reference to an offence created by section 6 of the 
Crimes Act 1914
 
or Part 2.4 of the 
Criminal Code
 that relates to Part 21 of this Act.

</details>