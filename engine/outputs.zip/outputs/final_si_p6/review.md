# Review: final_si_p6 — 4 rows


---

## Row 1: P6-I1 · n/a · **KNOWN**
- **Law:** Personal Data Protection Act 2012  
- **Confidence:** 0.6  
- **Source:** https://sso.agc.gov.sg/Act/PDPA2012  
- **Coverage:** Horizontal

> **Verbatim snippet:** NO_EVIDENCE_FOUND_PENDING_REVIEW

**Rationale:** No qualifying provision found for P6-I1 after a full-corpus sweep. The configured governing law is cited as the reference basis (score-0 pattern, A3).

**Notes:** Absence row (NO_EVIDENCE_FOUND_PENDING_REVIEW): human approval required before this becomes a score-0 final row (P3.5 A3).

<details><summary>Full section text (from graph)</summary>

(provision not found in graph)

</details>

---

## Row 2: P6-I2 · n/a · **KNOWN**
- **Law:** Personal Data Protection Act 2012  
- **Confidence:** 0.6  
- **Source:** https://sso.agc.gov.sg/Act/PDPA2012  
- **Coverage:** Horizontal

> **Verbatim snippet:** NO_EVIDENCE_FOUND_PENDING_REVIEW

**Rationale:** No qualifying provision found for P6-I2 after a full-corpus sweep. The configured governing law is cited as the reference basis (score-0 pattern, A3).

**Notes:** Absence row (NO_EVIDENCE_FOUND_PENDING_REVIEW): human approval required before this becomes a score-0 final row (P3.5 A3).

<details><summary>Full section text (from graph)</summary>

(provision not found in graph)

</details>

---

## Row 3: P6-I3 · n/a · **KNOWN**
- **Law:** Personal Data Protection Act 2012  
- **Confidence:** 0.6  
- **Source:** https://sso.agc.gov.sg/Act/PDPA2012  
- **Coverage:** Horizontal

> **Verbatim snippet:** NO_EVIDENCE_FOUND_PENDING_REVIEW

**Rationale:** No qualifying provision found for P6-I3 after a full-corpus sweep. The configured governing law is cited as the reference basis (score-0 pattern, A3).

**Notes:** Absence row (NO_EVIDENCE_FOUND_PENDING_REVIEW): human approval required before this becomes a score-0 final row (P3.5 A3).

<details><summary>Full section text (from graph)</summary>

(provision not found in graph)

</details>

---

## Row 4: P6-I4 · n/a · **KNOWN**
- **Law:** Personal Data Protection Act 2012  
- **Confidence:** 0.6  
- **Source:** https://sso.agc.gov.sg/Act/PDPA2012  
- **Coverage:** Horizontal

> **Verbatim snippet:** NO_EVIDENCE_FOUND_PENDING_REVIEW

**Rationale:** No qualifying provision found for P6-I4 after a full-corpus sweep. The configured governing law is cited as the reference basis (score-0 pattern, A3).

**Notes:** Absence row (NO_EVIDENCE_FOUND_PENDING_REVIEW): human approval required before this becomes a score-0 final row (P3.5 A3).

<details><summary>Full section text (from graph)</summary>

(provision not found in graph)

</details>