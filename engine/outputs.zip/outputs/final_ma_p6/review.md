# Review: final_ma_p6 — 8 rows


---

## Row 1: P6-I1 · n/a · **KNOWN**
- **Law:** Personal Data Protection Act 2010 (Act 709)  
- **Confidence:** 0.6  
- **Source:** https://lom.agc.gov.my/act-detail.php?act=709  
- **Coverage:** Horizontal

> **Verbatim snippet:** NO_EVIDENCE_FOUND_PENDING_REVIEW

**Rationale:** No qualifying provision found for P6-I1 after a full-corpus sweep. The configured governing law is cited as the reference basis (score-0 pattern, A3).

**Notes:** Absence row (NO_EVIDENCE_FOUND_PENDING_REVIEW): human approval required before this becomes a score-0 final row (P3.5 A3).

<details><summary>Full section text (from graph)</summary>

(provision not found in graph)

</details>

---

## Row 2: P6-I2 · n/a · **KNOWN**
- **Law:** Personal Data Protection Act 2010 (Act 709)  
- **Confidence:** 0.6  
- **Source:** https://lom.agc.gov.my/act-detail.php?act=709  
- **Coverage:** Horizontal

> **Verbatim snippet:** NO_EVIDENCE_FOUND_PENDING_REVIEW

**Rationale:** No qualifying provision found for P6-I2 after a full-corpus sweep. The configured governing law is cited as the reference basis (score-0 pattern, A3).

**Notes:** Absence row (NO_EVIDENCE_FOUND_PENDING_REVIEW): human approval required before this becomes a score-0 final row (P3.5 A3).

<details><summary>Full section text (from graph)</summary>

(provision not found in graph)

</details>

---

## Row 3: P6-I3 · n/a · **KNOWN**
- **Law:** Personal Data Protection Act 2010 (Act 709)  
- **Confidence:** 0.6  
- **Source:** https://lom.agc.gov.my/act-detail.php?act=709  
- **Coverage:** Horizontal

> **Verbatim snippet:** NO_EVIDENCE_FOUND_PENDING_REVIEW

**Rationale:** No qualifying provision found for P6-I3 after a full-corpus sweep. The configured governing law is cited as the reference basis (score-0 pattern, A3).

**Notes:** Absence row (NO_EVIDENCE_FOUND_PENDING_REVIEW): human approval required before this becomes a score-0 final row (P3.5 A3).

<details><summary>Full section text (from graph)</summary>

(provision not found in graph)

</details>

---

## Row 4: P6-I4 · s. 129(3) · **KNOWN**
- **Law:** Personal Data Protection Act (Act 709) 2010  
- **Confidence:** 0.98  
- **Source:** https://www.pdp.gov.my/ppdpv1/wp-content/uploads/2024/07/UNDANG-UNDANG-MALAYSIA_AKTA_PERLINDUNGAN_DATA_PERIBADI_2010_709_MALAY_AND-ENG_V2022.pdf  
- **Coverage:** Horizontal

> **Verbatim snippet:** a data user may transfer any personal data to a place outside Malaysia if— (a) the data subject has given his consent to the transfer;

**Rationale:** This section permits cross-border transfer of personal data subject to listed conditions. Maps to P6-I4 because it establishes a conditional compliance path for transfer, not a ban.

**Notes:** Discovery: master dataset already records s. 129 of this law. Modality: may (conditional on listed requirements); exceptions: none

<details><summary>Full section text (from graph)</summary>

**s. 129(1)** — (1) A data user shall not transfer any personal data of a data subject to a place outside Malaysia unless to such place as specified by the Minister, upon the recommendation of the Commissioner, by notification published in the Gazette. 85 Personal Data Protection

**s. 129(2)** — (2) For the purposes of subsection (1), the Minister may specify any place outside Malaysia if— (a) there is in that place in force any law which is substantially similar to this Act, or that serves the same purposes as this Act; or (b) that place ensures an adequate level of protection in relation to the processing of personal data which is at least equivalent to the level of protection afforded by this Act.

**s. 129(3)** — (3) Notwithstanding subsection (1), a data user may transfer any personal data to a place outside Malaysia if— (a) the data subject has given his consent to the transfer; (b) the transfer is necessary for the performance of a contract between the data subject and the data user; (c) the transfer is necessary for the conclusion or performance of a contract between the data user and a third party which— (i) is entered into at the request of the data subject; or (ii) is in the interests of the data subject; (d) the transfer is for the purpose of any legal proceedings or for the purpose of obtaining legal advice or for establishing, exercising or defending legal rights; (e) the data user has reasonable grounds for believing that in all circumstances of the case— (i) the transfer is for the avoidance or mitigation of adverse action against the data subject; (ii) it is not practicable to obtain the consent in writing of the data subject to that transfer; and (iii) if it was practicable to obtain such consent, the data subject would have given his consent; (f) the data user has taken all reasonable precautions and exercised all due diligence to ensure that the personal 86 ACT 709 Laws of Malaysia data will not in that place be processed in any manner which, if that place is Malaysia, would be a contravention of this Act; (g) the transfer is necessary in order to protect the vital interests of the data subject; or (h) the transfer is necessary as being in the public interest in circumstances as determined by the Minister.

**s. 129(4)** — (4) Where the Commissioner has reasonable grounds for believing that in a place as specified under subsection (1) there is no longer in force any law which is substantially similar to this Act, or that serves the same purposes as this Act— (a) the Commissioner shall make such recommendations to the Minister who shall, either by cancelling or amending the notification made under subsection (1), cause that place to cease to be a place to which personal data may be transferred under this section; and (b) the data user shall cease to transfer any personal data of a data subject to such place with effect from the time as specified by the Minister in the notification.

**s. 129(5)** — (5) A data user who contravenes subsection (1) commits an offence and shall, on conviction, be liable to a fine not exceeding three hundred thousand ringgit or to imprisonment for a term not exceeding two years or to both.

**s. 129(6)** — (6) For the purposes of this section, “adverse action”, in relation to a data subject, means any action that may adversely affect the data subject’s rights, benefits, privileges, obligations or interests. Unlawful collecting, etc., of personal data

</details>

---

## Row 5: P6-I4 · s. 4.10.3 · **KNOWN**
- **Law:** Personal Data Protection Code Of Practice For Banking Sector And Financial Institutions 2017  
- **Confidence:** 0.96  
- **Source:** https://www.pdp.gov.my/ppdpv1/wp-content/uploads/2024/08/170816-ABM-Code-Of-Practice-CLOcv04-FINAL_CLEAN.pdf  
- **Coverage:** Sectoral (Banking and financial institutions)

> **Verbatim snippet:** ensure that binding letters are exchanged or appropriate contractual clauses are inserted into contracts with overseas recipients of personal data

**Rationale:** This section recommends that Data Users use binding letters or contractual clauses for transfers of personal data abroad. Maps to P6-I4 because it establishes a conditional cross-border transfer regime: transfer is permitted if contractual safeguards are in place.

**Notes:** Discovery: master dataset already records s. 4.10.3 of this law. Modality: should/recommended; exceptions: none

<details><summary>Full section text (from graph)</summary>

**s. 4.10.3** — 4.10.3 Based on the above, it is recommended that Data Users: (i) address the issue of the transfer of personal data abroad either within their respective Privacy Notices or by addressing the same within the contract between the Data User and Data Subject; and (ii) ensure that binding letters are exchanged or appropriate contractual clauses are inserted into contracts with overseas recipients of personal data, in order to safeguard the transferred personal data as required by the Act, as expanded in 4.10.4 below. PDP Code Of Practice For The Banking And Financial Sector Part 4 47

</details>

---

## Row 6: P6-I4 · s. 129(1) · **KNOWN**
- **Law:** Personal Data Protection Act (Act 709) 2010  
- **Confidence:** 0.98  
- **Source:** https://www.pdp.gov.my/ppdpv1/wp-content/uploads/2024/07/UNDANG-UNDANG-MALAYSIA_AKTA_PERLINDUNGAN_DATA_PERIBADI_2010_709_MALAY_AND-ENG_V2022.pdf  
- **Coverage:** Horizontal

> **Verbatim snippet:** A data user shall not transfer any personal data of a data subject to a place outside Malaysia unless to such place as specified by the Minister, upon the recommendation of the Commissioner, by notification published in the Gazette.

**Rationale:** This section prohibits a data user from transferring personal data abroad unless the destination is ministerially specified via Gazette notification. Maps to P6-I4 because it creates a conditional cross-border transfer regime with a compliance path, not a total ban.

**Notes:** Discovery: master dataset already records s. 129 of this law. Modality: shall not ... unless; exceptions: unless to such place as specified by the Minister, upon the recommendation of the Commissioner, by notification published in the Gazette

<details><summary>Full section text (from graph)</summary>

**s. 129(1)** — (1) A data user shall not transfer any personal data of a data subject to a place outside Malaysia unless to such place as specified by the Minister, upon the recommendation of the Commissioner, by notification published in the Gazette. 85 Personal Data Protection

**s. 129(2)** — (2) For the purposes of subsection (1), the Minister may specify any place outside Malaysia if— (a) there is in that place in force any law which is substantially similar to this Act, or that serves the same purposes as this Act; or (b) that place ensures an adequate level of protection in relation to the processing of personal data which is at least equivalent to the level of protection afforded by this Act.

**s. 129(3)** — (3) Notwithstanding subsection (1), a data user may transfer any personal data to a place outside Malaysia if— (a) the data subject has given his consent to the transfer; (b) the transfer is necessary for the performance of a contract between the data subject and the data user; (c) the transfer is necessary for the conclusion or performance of a contract between the data user and a third party which— (i) is entered into at the request of the data subject; or (ii) is in the interests of the data subject; (d) the transfer is for the purpose of any legal proceedings or for the purpose of obtaining legal advice or for establishing, exercising or defending legal rights; (e) the data user has reasonable grounds for believing that in all circumstances of the case— (i) the transfer is for the avoidance or mitigation of adverse action against the data subject; (ii) it is not practicable to obtain the consent in writing of the data subject to that transfer; and (iii) if it was practicable to obtain such consent, the data subject would have given his consent; (f) the data user has taken all reasonable precautions and exercised all due diligence to ensure that the personal 86 ACT 709 Laws of Malaysia data will not in that place be processed in any manner which, if that place is Malaysia, would be a contravention of this Act; (g) the transfer is necessary in order to protect the vital interests of the data subject; or (h) the transfer is necessary as being in the public interest in circumstances as determined by the Minister.

**s. 129(4)** — (4) Where the Commissioner has reasonable grounds for believing that in a place as specified under subsection (1) there is no longer in force any law which is substantially similar to this Act, or that serves the same purposes as this Act— (a) the Commissioner shall make such recommendations to the Minister who shall, either by cancelling or amending the notification made under subsection (1), cause that place to cease to be a place to which personal data may be transferred under this section; and (b) the data user shall cease to transfer any personal data of a data subject to such place with effect from the time as specified by the Minister in the notification.

**s. 129(5)** — (5) A data user who contravenes subsection (1) commits an offence and shall, on conviction, be liable to a fine not exceeding three hundred thousand ringgit or to imprisonment for a term not exceeding two years or to both.

**s. 129(6)** — (6) For the purposes of this section, “adverse action”, in relation to a data subject, means any action that may adversely affect the data subject’s rights, benefits, privileges, obligations or interests. Unlawful collecting, etc., of personal data

</details>

---

## Row 7: P6-I4 · s. 4.10.1 · **KNOWN**
- **Law:** Personal Data Protection Code Of Practice For Banking Sector And Financial Institutions 2017  
- **Confidence:** 0.98  
- **Source:** https://www.pdp.gov.my/ppdpv1/wp-content/uploads/2024/08/170816-ABM-Code-Of-Practice-CLOcv04-FINAL_CLEAN.pdf  
- **Coverage:** Sectoral (Banking sector and financial institutions)

> **Verbatim snippet:** The Act prohibits the transfer of personal data outside of Malaysia unless the transfer is to a country with sufficient data protection laws, as specified by the Minister in a Government Gazette

**Rationale:** This section prohibits transfer of personal data outside Malaysia unless an adequacy condition is met. Maps to P6-I4 because it establishes a conditional cross-border flow regime: transfer is permitted if the specified legal condition is satisfied.

**Notes:** Discovery: master dataset already records s. 4.10.1 of this law. Modality: Prohibits unless (conditional exception); exceptions: Transfer is allowed if the adequacy/specified-country condition is met

<details><summary>Full section text (from graph)</summary>

**s. 4.10.1** — 4.10.1 The Act prohibits the transfer of personal data outside of Malaysia unless the transfer is to a country with sufficient data protection laws, as specified by the Minister in a Government Gazette, which will be based on the Commissioner’s recommendation to the Minister.

</details>

---

## Row 8: P6-I4 · s. 4.10.2 · **KNOWN**
- **Law:** Personal Data Protection Code Of Practice For Banking Sector And Financial Institutions 2017  
- **Confidence:** 0.93  
- **Source:** https://www.pdp.gov.my/ppdpv1/wp-content/uploads/2024/08/170816-ABM-Code-Of-Practice-CLOcv04-FINAL_CLEAN.pdf  
- **Coverage:** Sectoral (Banking sector and financial institutions)

> **Verbatim snippet:** the Act expressly permits the transfer of personal data abroad where: (i) the Data Subject has consented to the transfer; or (ii) the transfer is necessary for the performance of a contract between the Data User and the Data Subject

**Rationale:** This section permits cross-border transfer of personal data only if specified conditions are met. Maps to P6-I4 because it establishes a conditional compliance path (consent/contract/vital interests/public interest) rather than a ban.

**Notes:** Discovery: master dataset already records s. 4.10.2 of this law. Modality: permits (conditional); exceptions: none

<details><summary>Full section text (from graph)</summary>

**s. 4.10.2** — 4.10.2 Notwithstanding the above-mentioned prohibition, the Act expressly permits the transfer of personal data abroad where: (i) the Data Subject has consented to the transfer; or (ii) the transfer is necessary for the performance of a contract between the Data User and the Data Subject (for example where a customer gives the Data User an order to transfer money into the account of a third party); or (iii) the transfer is necessary to perform or conclude a contract between the Data User and third party which has been entered into at the request or in the interest of the Data Subject; or (iv) the transfer is for legal proceedings or obtaining legal advice; or (v) the Data User has reasonable grounds for doing so; or (vi) the Data User has taken reasonable precautions to ensure the personal data will not be processed in any manner which contravenes the Act; or (vii) the transfer is necessary to protect the vital interests of the Data Subject (this would relate to matters of life and death as defined in the Act); or (viii) the transfer is necessary as being in public interest as determined by the Minister.

</details>